module github.com/usewhale/whale

go 1.26.2

require (
	github.com/BurntSushi/toml v1.5.0
	github.com/alecthomas/chroma/v2 v2.14.0
	github.com/charmbracelet/bubbles v1.0.0
	github.com/charmbracelet/bubbletea v1.3.10
	github.com/charmbracelet/glamour v0.9.1
	github.com/charmbracelet/lipgloss v1.1.0
	github.com/charmbracelet/x/ansi v0.11.6
	github.com/charmbracelet/x/term v0.2.2
	github.com/erikgeiser/coninput v0.0.0-20211004153227-1c3628e74d0f
	github.com/fastschema/qjs v0.0.6
	github.com/google/uuid v1.6.0
	github.com/mattn/go-runewidth v0.0.19
	github.com/modelcontextprotocol/go-sdk v1.5.0
	github.com/muesli/termenv v0.16.0
	github.com/spf13/cobra v1.10.1
	github.com/spf13/pflag v1.0.9
	github.com/yuin/goldmark v1.7.8
	golang.org/x/net v0.33.0
	golang.org/x/sys v0.41.0
	golang.org/x/text v0.23.0
)

require (
	github.com/atotto/clipboard v0.1.4 // indirect
	github.com/aymanbagabas/go-osc52/v2 v2.0.1 // indirect
	github.com/aymerick/douceur v0.2.0 // indirect
	github.com/charmbracelet/colorprofile v0.4.1 // indirect
	github.com/charmbracelet/x/cellbuf v0.0.15 // indirect
	github.com/clipperhouse/displaywidth v0.9.0 // indirect
	github.com/clipperhouse/stringish v0.1.1 // indirect
	github.com/clipperhouse/uax29/v2 v2.5.0 // indirect
	github.com/creack/pty v1.1.24 // indirect
	github.com/dlclark/regexp2 v1.11.0 // indirect
	github.com/google/jsonschema-go v0.4.2 // indirect
	github.com/gorilla/css v1.0.1 // indirect
	github.com/inconshreveable/mousetrap v1.1.0 // indirect
	github.com/lucasb-eyer/go-colorful v1.3.0 // indirect
	github.com/mattn/go-isatty v0.0.20 // indirect
	github.com/mattn/go-localereader v0.0.1 // indirect
	github.com/microcosm-cc/bluemonday v1.0.27 // indirect
	github.com/muesli/ansi v0.0.0-20230316100256-276c6243b2f6 // indirect
	github.com/muesli/cancelreader v0.2.2 // indirect
	github.com/muesli/reflow v0.3.0 // indirect
	github.com/rivo/uniseg v0.4.7 // indirect
	github.com/segmentio/asm v1.1.3 // indirect
	github.com/segmentio/encoding v0.5.4 // indirect
	github.com/tetratelabs/wazero v1.9.0 // indirect
	github.com/xo/terminfo v0.0.0-20220910002029-abceb7e1c41e // indirect
	github.com/yosida95/uritemplate/v3 v3.0.2 // indirect
	github.com/yuin/goldmark-emoji v1.0.5 // indirect
	golang.org/x/oauth2 v0.35.0 // indirect
)
