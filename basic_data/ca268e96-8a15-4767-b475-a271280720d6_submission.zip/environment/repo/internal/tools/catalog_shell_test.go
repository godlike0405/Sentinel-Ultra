package tools

import (
	"strconv"
	"strings"
	"testing"

	"github.com/usewhale/whale/internal/core"
	"github.com/usewhale/whale/internal/shell"
)

func TestShellRunDescriptionIncludesPowerShellRuntimeGuidance(t *testing.T) {
	desc := shellRunDescriptionFor(shell.RuntimeDescription{
		GOOS: "windows",
		Spec: shell.Spec{Kind: shell.KindPowerShell, DisplayName: "PowerShell"},
	}, defaultForegroundShellWaitConfig())
	for _, want := range []string{
		"Run a shell command from the current Whale workspace.",
		"Runtime shell: PowerShell",
		"Use PowerShell syntax",
		"Get-ChildItem",
		"Select-String",
		"$env:TEMP",
		"$env:FOO",
		"read_file",
		"list_dir",
		"Avoid POSIX-only assumptions",
	} {
		if !strings.Contains(desc, want) {
			t.Fatalf("description missing %q:\n%s", want, desc)
		}
	}
}

func TestShellRunDescriptionIncludesCmdRuntimeGuidance(t *testing.T) {
	desc := shellRunDescriptionFor(shell.RuntimeDescription{
		GOOS: "windows",
		Spec: shell.Spec{Kind: shell.KindCmd, DisplayName: "cmd.exe"},
	}, defaultForegroundShellWaitConfig())
	for _, want := range []string{
		"Runtime shell: cmd.exe",
		"Use cmd.exe syntax",
		"dir",
		"findstr",
		"%TEMP%",
		"%FOO%",
		"read_file",
		"list_dir",
		"Avoid PowerShell-only syntax",
	} {
		if !strings.Contains(desc, want) {
			t.Fatalf("description missing %q:\n%s", want, desc)
		}
	}
}

func TestShellRunDescriptionWarnsAgainstDestructiveGitRestore(t *testing.T) {
	desc := shellRunDescriptionFor(shell.RuntimeDescription{}, defaultForegroundShellWaitConfig())
	for _, want := range []string{
		"destructive workspace restore operations",
		"git checkout -- <path>",
		"git restore",
		"git reset --hard",
		"git clean",
		"Whale's /rewind command or /checkpoint alias",
		"unless the user explicitly asked to discard local changes",
	} {
		if !strings.Contains(desc, want) {
			t.Fatalf("description missing %q:\n%s", want, desc)
		}
	}
}

func TestShellRunDescriptionUsesConfiguredForegroundWait(t *testing.T) {
	waitCfg := foregroundShellWaitConfig{DefaultMS: 45000, MaxMS: 240000}
	desc := shellRunDescriptionFor(shell.RuntimeDescription{}, waitCfg)
	if !strings.Contains(desc, "Foreground wait defaults to 45000ms and clamps at 240000ms") {
		t.Fatalf("description missing configured wait values:\n%s", desc)
	}
	timeoutDesc := shellRunTimeoutDescription(waitCfg)
	if !strings.Contains(timeoutDesc, "defaults to 45000 and clamps at 240000") {
		t.Fatalf("timeout description missing configured wait values:\n%s", timeoutDesc)
	}
}

func TestShellReadOnlyCheckRejectsWindowsShellCommands(t *testing.T) {
	powerShellSpec := shellRunReadOnlySpecFor(shell.KindPowerShell)
	cmdSpec := shellRunReadOnlySpecFor(shell.KindCmd)

	for _, tc := range []struct {
		name    string
		spec    core.ToolSpec
		command string
	}{
		{name: "powershell list", spec: powerShellSpec, command: "Get-ChildItem internal"},
		{name: "powershell search", spec: powerShellSpec, command: "Select-String -Path internal/*.go -Pattern Runtime"},
		{name: "powershell double-quoted pattern", spec: powerShellSpec, command: `Select-String -Path internal/*.go -Pattern "Runtime|ToolGuidance"`},
		{name: "powershell single-quoted pattern", spec: powerShellSpec, command: `Select-String -Path internal/*.go -Pattern 'Runtime|ToolGuidance'`},
		{name: "cmd list", spec: cmdSpec, command: "dir internal"},
		{name: "cmd quoted path", spec: cmdSpec, command: `dir "x & y"`},
		{name: "cmd search", spec: cmdSpec, command: "findstr /s Runtime internal\\*.go"},
		{name: "cmd quoted pattern", spec: cmdSpec, command: `findstr /c:"Runtime|ToolGuidance" internal\*.go`},
		{name: "posix command on powershell runtime", spec: powerShellSpec, command: "ls internal"},
		{name: "posix command on cmd runtime", spec: cmdSpec, command: "ls internal"},
	} {
		t.Run(tc.name, func(t *testing.T) {
			call := core.ToolCall{Name: "shell_run", Input: `{"command":` + strconv.Quote(tc.command) + `}`}
			if core.IsReadOnlyToolCall(tc.spec, call) {
				t.Fatalf("expected %q to require approval", tc.command)
			}
		})
	}
}

func TestShellReadOnlyCheckRejectsChainedOrRedirectedCommands(t *testing.T) {
	powerShellSpec := shellRunReadOnlySpecFor(shell.KindPowerShell)
	cmdSpec := shellRunReadOnlySpecFor(shell.KindCmd)
	posixSpec := shellRunReadOnlySpecFor(shell.KindPOSIX)

	for _, tc := range []struct {
		name    string
		spec    core.ToolSpec
		command string
	}{
		{name: "powershell semicolon", spec: powerShellSpec, command: "Get-ChildItem .; Remove-Item foo"},
		{name: "powershell pipe", spec: powerShellSpec, command: "Select-String -Path internal/*.go -Pattern Runtime | Remove-Item foo"},
		{name: "powershell redirection", spec: powerShellSpec, command: "Get-ChildItem . > out.txt"},
		{name: "powershell subexpression", spec: powerShellSpec, command: "Get-ChildItem $(Remove-Item foo)"},
		{name: "powershell double-quoted subexpression", spec: powerShellSpec, command: `Get-ChildItem "$(Remove-Item foo)"`},
		{name: "powershell parenthesized command", spec: powerShellSpec, command: "Get-ChildItem (Remove-Item foo)"},
		{name: "cmd redirection", spec: cmdSpec, command: "dir . > out.txt"},
		{name: "cmd ampersand", spec: cmdSpec, command: "dir . & del foo"},
		{name: "cmd single quotes do not quote", spec: cmdSpec, command: "dir 'x & del foo & rem '"},
		{name: "cmd env expansion", spec: cmdSpec, command: "dir %TEMP%"},
		{name: "cmd caret escape", spec: cmdSpec, command: "dir ^& del foo"},
		{name: "newline separator", spec: cmdSpec, command: "dir .\ndel foo"},
		{name: "posix command substitution", spec: posixSpec, command: "ls $(rm foo)"},
		{name: "posix backtick substitution", spec: posixSpec, command: "ls `rm foo`"},
	} {
		t.Run(tc.name, func(t *testing.T) {
			call := core.ToolCall{Name: "shell_run", Input: `{"command":` + strconv.Quote(tc.command) + `}`}
			if core.IsReadOnlyToolCall(tc.spec, call) {
				t.Fatalf("expected %q to require approval", tc.command)
			}
		})
	}
}

func TestShellReadOnlyCheckRejectsUnsafeReadCommandArgs(t *testing.T) {
	spec := shellRunReadOnlySpecFor(shell.KindPOSIX)
	for _, command := range []string{
		"find . -delete",
		"find . -exec rm {} +",
		"find . -fprint out",
		"find . -fprint0 out",
		"find . -fprintf out %p",
		`find . "-exec" rm {} +`,
		`find . '-delete'`,
		`find . "-fprint0" out`,
		`find . -\exec rm {} +`,
		"git diff --output=out.patch",
		"git diff --output=out.patch | tail -80",
		"git diff --no-index /dev/null /etc/passwd",
		"git diff --no-index /dev/null ../secret.txt",
		"git -c core.pager=cat diff",
		"git -C /tmp status --short",
		"git -C ../private diff",
		"git show --ext-diff HEAD",
		`git show "--output=out.patch" HEAD`,
		"git log --textconv",
		"git branch -d feature",
		"git remote add origin git@example.com:repo.git",
		"git diff -- internal/tools/catalog_shell.go | sh",
		"git diff -- internal/tools/catalog_shell.go || tail -80",
		"git diff -- internal/tools/catalog_shell.go | tail -80 > out.txt",
		"git show HEAD:internal/app/config_file.go | sed -i '300,459p'",
		"git show HEAD:internal/app/config_file.go | sed -n '300,459w out.txt'",
		"git diff -- internal/tools/catalog_shell.go | tee out.txt",
		"git status --short && git branch -D feature",
		"cd /Users/goranka/Engineer/ai/dsk/whale-review-command && git diff | tail -80",
		"sort -o out.txt input.txt",
		"sort --output=out.txt input.txt",
		"rg --pre ./danger pattern",
		`rg "--pre=./danger" pattern`,
		`rg "--pre" ./danger pattern`,
	} {
		call := core.ToolCall{Name: "shell_run", Input: `{"command":` + strconv.Quote(command) + `}`}
		if core.IsReadOnlyToolCall(spec, call) {
			t.Fatalf("expected unsafe read-command args in %q to require approval", command)
		}
	}
}

func TestShellReadOnlyCheckRejectsTestAndBuildCommands(t *testing.T) {
	spec := shellRunReadOnlySpecFor(shell.KindPOSIX)
	for _, command := range []string{
		"make test",
		"make test-tui",
		"make test-evals",
		"make fmt-check",
		"make vet",
		"make build",
		"go test ./...",
		"go vet ./...",
		"npm run test -- --runInBand",
		"npm run typecheck",
		"python -m pytest tests",
		"cargo check --workspace",
	} {
		call := core.ToolCall{Name: "shell_run", Input: `{"command":` + strconv.Quote(command) + `}`}
		if core.IsReadOnlyToolCall(spec, call) {
			t.Fatalf("expected test/build command %q not to be strict read-only", command)
		}
	}
}

func TestShellReadOnlyCheckRejectsMutatingNearMisses(t *testing.T) {
	spec := shellRunReadOnlySpecFor(shell.KindPOSIX)
	for _, command := range []string{
		"make clean",
		"npm install lodash",
		"npm run lint -- --fix",
		"npx jest --updateSnapshot",
		"npx jest -u",
		"npx vitest run --update",
		"go testfoo ./...",
		"make test clean",
		"make test build",
		"make build clean",
		"make test GOCACHE_DIR=.gocache",
		"make test && rm -rf bin",
		"make test > out.txt",
	} {
		call := core.ToolCall{Name: "shell_run", Input: `{"command":` + strconv.Quote(command) + `}`}
		if core.IsReadOnlyToolCall(spec, call) {
			t.Fatalf("expected mutating or unsafe command %q to require approval", command)
		}
	}
}

func TestShellReadOnlyCheckAllowsQuotedSearchPatterns(t *testing.T) {
	spec := shellRunReadOnlySpecFor(shell.KindPOSIX)
	for _, command := range []string{
		`grep "Runtime|ToolGuidance" internal/tools/catalog_shell.go`,
		`grep 'Runtime;ToolGuidance' internal/tools/catalog_shell.go`,
		"git status -u",
		"git diff --cached",
		"git diff -- internal/tools/catalog_shell.go | tail -80",
		"git diff -- internal/tools/catalog_shell.go | head -40",
		"git show HEAD:internal/app/config_file.go | sed -n '300,459p'",
		"git branch --list 'feature/worktree-command' && git rev-parse --abbrev-ref HEAD",
		"git diff --stat HEAD 2>/dev/null; printf '%s\\n' ---; git ls-files | sort",
		"git log --oneline | grep feature | sort -u",
		"find internal -name '*.go' | sort",
		`echo "=== GIT STATUS ===" && git status && echo "" && echo "=== CURRENT BRANCH ===" && git branch --show-current && echo "" && echo "=== RECENT 5 COMMITS ===" && git log --oneline -5 && echo "" && echo "=== GO FILES UNDER internal/ ===" && find internal -name '*.go' -type f | wc -l`,
		`echo "=== git status ===" && git status && echo "" && echo "=== 最近5条提交 ===" && git log --oneline -5 && echo "" && echo "=== 当前分支 ===" && git branch --show-current && echo "" && echo "=== internal 下 Go 文件数量 ===" && find internal -name '*.go' -type f | wc -l && echo "" && echo "=== internal 下 Go 文件（含测试文件）明细 ===" && find internal -name '*.go' -type f | sed 's/.*\\.//' | sort | uniq -c | sort -rn`,
		"git shortlog -sne HEAD",
		"rg whale internal | wc -l",
		"git diff --no-index /dev/null internal/tools/catalog_shell.go",
		"git branch --show-current",
		"git remote -v",
		"git remote get-url origin",
		"git config --get remote.origin.url",
		"ls -u",
	} {
		call := core.ToolCall{Name: "shell_run", Input: `{"command":` + strconv.Quote(command) + `}`}
		if !core.IsReadOnlyToolCall(spec, call) {
			t.Fatalf("expected quoted search pattern in %q to be read-only", command)
		}
	}
}

func TestShellReadOnlyCheckRejectsPOSIXExpansionSyntax(t *testing.T) {
	spec := shellRunReadOnlySpecFor(shell.KindPOSIX)
	for _, command := range []string{
		`grep Runtime internal/*.go`,
		`grep Runtime $HOME/file`,
		`ls \; rm foo`,
		`ls "unterminated`,
		`echo hi # comment`,
	} {
		call := core.ToolCall{Name: "shell_run", Input: `{"command":` + strconv.Quote(command) + `}`}
		if core.IsReadOnlyToolCall(spec, call) {
			t.Fatalf("expected POSIX shell expansion syntax in %q to require approval", command)
		}
	}
}

func TestShellReadOnlyCheckIsRuntimeSpecific(t *testing.T) {
	posixSpec := shellRunReadOnlySpecFor(shell.KindPOSIX)
	for _, command := range []string{
		"Get-ChildItem internal",
		"Select-String -Path internal/*.go -Pattern Runtime",
		"dir internal",
		"findstr /s Runtime internal\\*.go",
	} {
		call := core.ToolCall{Name: "shell_run", Input: `{"command":` + strconv.Quote(command) + `}`}
		if core.IsReadOnlyToolCall(posixSpec, call) {
			t.Fatalf("expected POSIX runtime to reject Windows command %q", command)
		}
	}
}

func shellRunReadOnlySpecFor(kind shell.Kind) core.ToolSpec {
	return core.DescribeTool(toolFn{
		name: "shell_run",
		readOnlyCheck: shellReadOnlyCheckFor(shell.RuntimeDescription{
			Spec: shell.Spec{Kind: kind},
		}),
	})
}
