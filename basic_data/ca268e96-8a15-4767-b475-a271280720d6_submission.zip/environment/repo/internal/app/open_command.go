package app

import (
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"

	appcommands "github.com/usewhale/whale/internal/commands"
)

type OpenCommand struct {
	Path string
	Cmd  *exec.Cmd
}

func IsOpenCommandLine(line string) bool {
	return appcommands.IsOpenCommandLine(line)
}

func (a *App) PrepareOpenCommand(line string) (OpenCommand, error) {
	target, err := ResolveOpenPath(a.workspaceRoot, openCommandArg(line))
	if err != nil {
		return OpenCommand{}, err
	}
	parts, err := ResolveOpenCommand(os.LookupEnv, exec.LookPath, runtime.GOOS, target)
	if err != nil {
		return OpenCommand{}, err
	}
	args := append(append([]string{}, parts[1:]...), target)
	cmd := exec.Command(parts[0], args...)
	if a.workspaceRoot != "" {
		cmd.Dir = a.workspaceRoot
	}
	return OpenCommand{Path: target, Cmd: cmd}, nil
}

func (a *App) ExecuteOpenCommand(line string) (string, error) {
	openCmd, err := a.PrepareOpenCommand(line)
	if err != nil {
		return "", err
	}
	openCmd.Cmd.Stdin = os.Stdin
	openCmd.Cmd.Stdout = os.Stdout
	openCmd.Cmd.Stderr = os.Stderr
	if err := openCmd.Cmd.Run(); err != nil {
		return "", fmt.Errorf("open editor: %w", err)
	}
	return OpenCommandSuccessText(openCmd.Path), nil
}

func OpenCommandSuccessText(path string) string {
	return "Opened " + path
}

func openCommandArg(line string) string {
	trimmed := strings.TrimSpace(line)
	if trimmed == "/open" {
		return ""
	}
	if strings.HasPrefix(trimmed, "/open ") || strings.HasPrefix(trimmed, "/open\t") {
		return strings.TrimSpace(trimmed[len("/open"):])
	}
	return ""
}

func ResolveOpenPath(workspaceRoot, raw string) (string, error) {
	base := strings.TrimSpace(workspaceRoot)
	if base == "" {
		base = "."
	}
	baseAbs, err := filepath.Abs(filepath.Clean(base))
	if err != nil {
		return "", err
	}
	baseReal, err := filepath.EvalSymlinks(baseAbs)
	if err != nil {
		return "", err
	}
	baseReal = filepath.Clean(baseReal)
	target := normalizeOpenPathArg(strings.TrimSpace(raw))
	target, err = expandOpenHomePath(target)
	if err != nil {
		return "", err
	}
	relativeTarget := target != "" && !filepath.IsAbs(target)
	if target == "" {
		target = baseAbs
	} else if relativeTarget {
		target = filepath.Join(baseAbs, target)
	}
	abs, err := filepath.Abs(filepath.Clean(target))
	if err != nil {
		return "", err
	}
	if relativeTarget && !openPathInsideWorkspace(baseAbs, abs) {
		return "", openPathOutsideWorkspaceError(baseAbs, abs)
	}
	if _, err := os.Stat(abs); err != nil {
		if errors.Is(err, os.ErrNotExist) {
			return "", fmt.Errorf("open target does not exist: %s", abs)
		}
		return "", err
	}
	real, err := filepath.EvalSymlinks(abs)
	if err != nil {
		return "", err
	}
	if !openPathInsideWorkspace(baseReal, filepath.Clean(real)) {
		return "", openPathOutsideWorkspaceError(baseAbs, abs)
	}
	return abs, nil
}

func normalizeOpenPathArg(raw string) string {
	if len(raw) < 2 || raw[0] != '"' || raw[len(raw)-1] != '"' {
		return raw
	}
	inner := raw[1 : len(raw)-1]
	var b strings.Builder
	b.Grow(len(inner))
	for i := 0; i < len(inner); i++ {
		c := inner[i]
		if c == '\\' && i+1 < len(inner) {
			next := inner[i+1]
			if next == '"' || next == '\\' {
				b.WriteByte(next)
				i++
				continue
			}
		}
		b.WriteByte(c)
	}
	return b.String()
}

func expandOpenHomePath(path string) (string, error) {
	if path != "~" && !strings.HasPrefix(path, "~/") {
		return path, nil
	}
	home, err := os.UserHomeDir()
	if err != nil {
		return "", err
	}
	if home == "" {
		return "", errors.New("home directory is unavailable")
	}
	if path == "~" {
		return home, nil
	}
	return filepath.Join(home, strings.TrimPrefix(path, "~/")), nil
}

func openPathOutsideWorkspaceError(workspaceRoot, target string) error {
	return fmt.Errorf("Cannot open files outside the current workspace.\n\nCurrent workspace:\n  %s\n\nRequested file:\n  %s\n\nUse /open with a path inside the workspace, or run your editor directly for external files.", workspaceRoot, target)
}

func openPathInsideWorkspace(workspaceRoot, target string) bool {
	rel, err := filepath.Rel(workspaceRoot, target)
	if err != nil {
		return false
	}
	return rel != ".." && !strings.HasPrefix(rel, ".."+string(os.PathSeparator)) && !filepath.IsAbs(rel)
}

func ResolveEditorCommand(lookupEnv func(string) (string, bool), goos string) ([]string, error) {
	return ResolveOpenCommand(lookupEnv, exec.LookPath, goos, "")
}

func ResolveOpenCommand(lookupEnv func(string) (string, bool), lookupPath func(string) (string, error), goos, target string) ([]string, error) {
	for _, name := range []string{"VISUAL", "EDITOR"} {
		if value, ok := lookupEnv(name); ok && strings.TrimSpace(value) != "" {
			parts, err := splitEditorCommand(value)
			if err != nil {
				return nil, fmt.Errorf("%s: %w", name, err)
			}
			if len(parts) == 0 {
				continue
			}
			return parts, nil
		}
	}
	if goos == "windows" {
		if target != "" {
			if info, err := os.Stat(target); err == nil && info.IsDir() {
				return []string{"explorer"}, nil
			}
		}
		return []string{"notepad"}, nil
	}
	for _, editor := range []string{"vim", "vi"} {
		path, err := lookupPath(editor)
		if err == nil && strings.TrimSpace(path) != "" {
			return []string{path}, nil
		}
	}
	switch goos {
	case "darwin", "linux":
		return nil, errors.New("no editor found: set VISUAL or EDITOR, or install vim/vi")
	default:
		return []string{"vi"}, nil
	}
}

func splitEditorCommand(input string) ([]string, error) {
	var out []string
	var b strings.Builder
	var quote rune
	runes := []rune(input)
	for i := 0; i < len(runes); i++ {
		r := runes[i]
		if r == '\\' && quote != '\'' && i+1 < len(runes) && isEditorEscapable(runes[i+1]) {
			i++
			b.WriteRune(runes[i])
			continue
		}
		if quote != 0 {
			if r == quote {
				quote = 0
				continue
			}
			b.WriteRune(r)
			continue
		}
		switch r {
		case '\'', '"':
			quote = r
		case ' ', '\t', '\n', '\r':
			if b.Len() > 0 {
				out = append(out, b.String())
				b.Reset()
			}
		default:
			b.WriteRune(r)
		}
	}
	if quote != 0 {
		return nil, errors.New("unterminated quote")
	}
	if b.Len() > 0 {
		out = append(out, b.String())
	}
	if len(out) == 0 {
		return nil, errors.New("empty editor command")
	}
	return out, nil
}

func isEditorEscapable(r rune) bool {
	switch r {
	case '\\', '\'', '"', ' ', '\t', '\n', '\r':
		return true
	default:
		return false
	}
}
