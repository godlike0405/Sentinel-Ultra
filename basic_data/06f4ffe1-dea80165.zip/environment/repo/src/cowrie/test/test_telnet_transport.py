# SPDX-FileCopyrightText: 2026 Michel Oosterhof <michel@oosterhof.net>
#
# SPDX-License-Identifier: BSD-3-Clause

# ABOUTME: Tests for telnet transport negotiation error handling.
# ABOUTME: Covers edge cases in telnet option negotiation chaining.

from __future__ import annotations

import gc
import unittest
from typing import TYPE_CHECKING
from unittest.mock import MagicMock, patch

from twisted.conch.telnet import (
    ECHO,
    NAWS,
    AlreadyNegotiating,
    ITelnetProtocol,
    TelnetTransport,
)
from twisted.internet.error import ConnectionDone
from twisted.python import failure, log
from zope.interface import implementer

from cowrie.telnet.transport import CowrieTelnetTransport
from cowrie.telnet.userauth import HoneyPotTelnetAuthProtocol
from cowrie.test.eventcapture import capture_events

if TYPE_CHECKING:
    from collections.abc import Callable


class MockOptionState:
    """Mock for Twisted's _OptionState."""

    def __init__(
        self, him_result: MagicMock | None = None, us_result: MagicMock | None = None
    ) -> None:
        self.him = MagicMock()
        self.him.onResult = him_result
        self.us = MagicMock()
        self.us.onResult = us_result


class TestHandleNegotiationError(unittest.TestCase):
    """Tests for _handleNegotiationError edge cases."""

    def setUp(self) -> None:
        """Set up test fixtures."""
        self.transport = CowrieTelnetTransport()
        # Mock the transport's internal state
        self.transport.transport = MagicMock()

    def test_handles_none_us_onResult(self) -> None:
        """Test that _handleNegotiationError handles None onResult for will/wont.

        When AlreadyNegotiating is raised but the negotiation completes before
        we can chain onto it, onResult will be None. This should not crash.
        """
        # Create a failure with AlreadyNegotiating
        f = failure.Failure(AlreadyNegotiating())

        # Mock getOptionState to return state with None onResult
        mock_state = MockOptionState(us_result=None)

        # This should not raise AttributeError
        # Using self.will as the func (will/wont use s.us.onResult)
        with patch.object(self.transport, "getOptionState", return_value=mock_state):
            try:
                self.transport._handleNegotiationError(f, self.transport.will, b"\x01")
            except AttributeError as e:
                self.fail(f"_handleNegotiationError raised AttributeError: {e}")

    def test_handles_none_him_onResult(self) -> None:
        """Test that _handleNegotiationError handles None onResult for do/dont.

        When AlreadyNegotiating is raised but the negotiation completes before
        we can chain onto it, onResult will be None. This should not crash.
        """
        # Create a failure with AlreadyNegotiating
        f = failure.Failure(AlreadyNegotiating())

        # Mock getOptionState to return state with None onResult
        mock_state = MockOptionState(him_result=None)

        # This should not raise AttributeError
        # Using self.do as the func (do/dont use s.him.onResult)
        with patch.object(self.transport, "getOptionState", return_value=mock_state):
            try:
                self.transport._handleNegotiationError(f, self.transport.do, b"\x01")
            except AttributeError as e:
                self.fail(f"_handleNegotiationError raised AttributeError: {e}")

    def test_chains_when_onResult_exists(self) -> None:
        """Test that callbacks are properly chained when onResult is not None."""
        f = failure.Failure(AlreadyNegotiating())

        # Create a mock Deferred for onResult
        mock_deferred = MagicMock()
        mock_deferred.addCallback = MagicMock(return_value=mock_deferred)
        mock_deferred.addErrback = MagicMock(return_value=mock_deferred)

        mock_state = MockOptionState(us_result=mock_deferred)

        with patch.object(self.transport, "getOptionState", return_value=mock_state):
            self.transport._handleNegotiationError(f, self.transport.will, b"\x01")

        # Verify callbacks were added
        mock_deferred.addCallback.assert_called_once()
        mock_deferred.addErrback.assert_called_once()


@implementer(ITelnetProtocol)
class EchoOnlyProtocol:
    """Minimal application protocol that only agrees to echo locally."""

    def enableLocal(self, option: bytes) -> bool:
        return option == ECHO

    def enableRemote(self, option: bytes) -> bool:
        return False

    def disableLocal(self, option: bytes) -> bool:
        return True

    def disableRemote(self, option: bytes) -> bool:
        return True

    def makeConnection(self, transport: object) -> None:
        pass

    def connectionMade(self) -> None:
        pass

    def dataReceived(self, data: bytes) -> None:
        pass

    def connectionLost(self, reason: failure.Failure) -> None:
        pass

    def unhandledCommand(self, command: bytes, argument: bytes) -> None:
        pass

    def unhandledSubnegotiation(self, command: bytes, data: list[bytes]) -> None:
        pass


class CollectingTransport:
    """Underlying TCP transport stub that records bytes written."""

    def __init__(self) -> None:
        self.data = b""

    def write(self, data: bytes) -> None:
        self.data += data

    def writeSequence(self, seq: list[bytes]) -> None:
        self.data += b"".join(seq)


class TestNegotiationDuringConnectionLost(unittest.TestCase):
    """Regression tests for issue #40177.

    A telnet client that initiates option negotiation but never answers it
    leaves a negotiation permanently pending. A later willChain/wontChain on
    the same option chains retries onto the pending Deferred. When the
    connection is then lost, those retries used to fire an uncollected failed
    Deferred (AlreadyNegotiating) and mutate self.options while
    Telnet.connectionLost() iterates it, crashing the session right after a
    successful login.
    """

    def setUp(self) -> None:
        self.transport = CowrieTelnetTransport()
        self.tcp = CollectingTransport()
        self.transport.protocol = EchoOnlyProtocol()  # type: ignore[assignment]
        self.transport.transport = self.tcp  # type: ignore[assignment]
        self.transport.startTime = 0.0
        self.transport.setTimeout = lambda *a: None  # type: ignore[method-assign]

    def _drive_pending_negotiation(self) -> None:
        """Reproduce the production flow against a non-answering client.

        telnet_User -> willChain(ECHO); the client never answers, so the
        negotiation stays pending. A failed login (_ebLogin) then issues
        wontChain(ECHO), and a second telnet_User issues willChain(ECHO)
        again -- both raise AlreadyNegotiating and chain onto the pending
        Deferred.
        """
        self.transport.willChain(ECHO)
        self.transport.wontChain(ECHO)
        self.transport.willChain(ECHO)

    def test_connection_lost_after_pending_negotiation_is_clean(self) -> None:
        errors: list[failure.Failure] = []

        def observer(event: dict) -> None:
            if event.get("isError"):
                f = event.get("failure")
                if f is not None:
                    errors.append(f)

        log.addObserver(observer)
        try:
            self._drive_pending_negotiation()
            # Must not raise (e.g. "dictionary changed size during iteration").
            self.transport.connectionLost(failure.Failure(ConnectionDone()))
            # Force any uncollected failed Deferreds to be logged via __del__.
            gc.collect()
        finally:
            log.removeObserver(observer)

        unhandled = [f for f in errors if f.check(AlreadyNegotiating)]
        self.assertEqual(
            unhandled,
            [],
            f"connection teardown left {len(unhandled)} unhandled "
            "AlreadyNegotiating Deferred(s)",
        )

    def test_no_negotiation_while_closing(self) -> None:
        """While closing, negotiation must not touch self.options.

        Telnet.connectionLost() iterates self.options.values(); driving a
        negotiation there (via getOptionState -> setdefault) would insert a
        new key and raise "dictionary changed size during iteration". Once
        _closing is set, the chaining helpers must be no-ops.
        """
        self.transport._closing = True

        before = dict(self.transport.options)
        self.assertIsNone(self.transport.willChain(ECHO))
        self.assertEqual(
            self.transport.options,
            before,
            "willChain mutated self.options during teardown",
        )
        self.assertEqual(self.tcp.data, b"")


class TestInvalidIACSequence(unittest.TestCase):
    """Regression test for issue #40218.

    Twisted's Telnet.dataReceived() raises ValueError("Stumped", b) when a
    client sends a byte after IAC (0xFF) that is not a recognised command --
    e.g. a scanner sending IAC 0x01 outside a WILL/DO envelope. Inherited
    unchanged, this propagates into the reactor as an "Unhandled Error" and
    tears the transport down without the normal connectionLost() cleanup. The
    override must catch it, log a telnet error, and drop the connection
    cleanly.
    """

    def setUp(self) -> None:
        self.transport = CowrieTelnetTransport()
        self.tcp = MagicMock()
        self.transport.transport = self.tcp
        self.dispatched = capture_events(self.transport)

    def _capture(self, run: Callable[[], None]) -> list[dict]:
        run()
        return [e for e in self.dispatched if e.get("eventid") == "cowrie.telnet.error"]

    def test_invalid_iac_byte_dropped_cleanly(self) -> None:
        # IAC (0xFF) followed by 0x01, which is not a valid IAC command byte.
        errors = self._capture(lambda: self.transport.dataReceived(b"\xff\x01"))

        self.tcp.loseConnection.assert_called_once_with()
        self.assertEqual(len(errors), 1)

    def test_valid_data_still_delivered(self) -> None:
        # A well-formed stream must pass through untouched.
        protocol = MagicMock()
        self.transport.protocol = protocol  # type: ignore[assignment]
        errors = self._capture(lambda: self.transport.dataReceived(b"hello"))

        protocol.dataReceived.assert_called_once_with(b"hello")
        self.tcp.loseConnection.assert_not_called()
        self.assertEqual(errors, [])

    def test_protocol_error_logs_no_traceback(self) -> None:
        # A byte the telnet parser rejects after IAC is expected garbage from a
        # non-telnet client (scanners). The error event records it; a full
        # traceback would just be log noise, so none is logged.
        self.transport._log = MagicMock()
        errors = self._capture(lambda: self.transport.dataReceived(b"\xff\x18"))

        self.assertEqual(len(errors), 1)
        self.tcp.loseConnection.assert_called_once_with()
        self.transport._log.failure.assert_not_called()

    def test_unexpected_valueerror_logs_traceback(self) -> None:
        # A ValueError from downstream honeypot code (not the telnet parser) is
        # a genuine bug and must still be logged with a full traceback.
        self.transport._log = MagicMock()
        protocol = MagicMock()
        protocol.dataReceived.side_effect = ValueError("boom")
        self.transport.protocol = protocol  # type: ignore[assignment]

        self.transport.dataReceived(b"hello")

        self.transport._log.failure.assert_called_once()
        self.tcp.loseConnection.assert_called_once_with()


class TestOptionLoggingDeduplication(unittest.TestCase):
    """A scanner flooding the same option negotiation is logged once."""

    def setUp(self) -> None:
        self.transport = CowrieTelnetTransport()
        self.transport.transport = MagicMock()
        # Normally initialised in connectionMade.
        self.transport._logged_options = set()
        self.dispatched = capture_events(self.transport)

    def _capture(self, run: Callable[[], None]) -> list[dict]:
        run()
        return [
            e for e in self.dispatched if e.get("eventid") == "cowrie.telnet.option"
        ]

    def test_repeated_negotiation_logged_once(self) -> None:
        def run() -> None:
            for _ in range(5):
                self.transport.telnet_WONT(NAWS)

        with patch.object(TelnetTransport, "telnet_WONT"):
            logs = self._capture(run)
        self.assertEqual(len(logs), 1)
        self.assertEqual(logs[0]["command"], "WONT")

    def test_distinct_negotiations_each_logged(self) -> None:
        def run() -> None:
            self.transport.telnet_WONT(NAWS)
            self.transport.telnet_WONT(NAWS)
            self.transport.telnet_WILL(NAWS)

        with (
            patch.object(TelnetTransport, "telnet_WONT"),
            patch.object(TelnetTransport, "telnet_WILL"),
        ):
            logs = self._capture(run)
        self.assertEqual(sorted(e["command"] for e in logs), ["WILL", "WONT"])


class TestLoginLineEndings(unittest.TestCase):
    """Login must accept the line endings a real telnetd does (issue #1461).

    Twisted's NVT layer only turns CR LF into a newline; a client that ends a
    line with a bare CR (PuTTY's "Return sends ^M"), CR NUL, or CR followed by
    the next line never delivers the LF the login LineReceiver waits for, so
    the login would stall at ``login:``.
    """

    def _harness(
        self,
    ) -> tuple[CowrieTelnetTransport, HoneyPotTelnetAuthProtocol, list[bytes]]:
        transport = CowrieTelnetTransport()
        transport.transport = MagicMock()
        capture_events(transport)
        auth = HoneyPotTelnetAuthProtocol(MagicMock())
        auth.transport = transport  # type: ignore[assignment]
        auth.factory = MagicMock()
        auth.factory.banner = b"banner\n"
        transport.protocol = auth  # type: ignore[assignment]
        auth.state = "User"
        lines: list[bytes] = []

        def spy_user(line: bytes) -> str:
            lines.append(line)
            return "Password"

        auth.telnet_User = spy_user  # type: ignore[method-assign]
        return transport, auth, lines

    def test_crlf_still_delivers_clean_line(self) -> None:
        transport, _auth, lines = self._harness()
        transport.dataReceived(b"root\r\n")
        self.assertEqual(lines, [b"root"])

    def test_bare_cr_delivers_clean_line(self) -> None:
        transport, _auth, lines = self._harness()
        transport.dataReceived(b"root\r")
        self.assertEqual(lines, [b"root"])

    def test_cr_nul_delivers_clean_line(self) -> None:
        transport, _auth, lines = self._harness()
        transport.dataReceived(b"root\r\x00")
        self.assertEqual(lines, [b"root"])

    def test_bare_cr_split_across_packets(self) -> None:
        # A bare CR arriving in its own packet (character-at-a-time telnet)
        # must terminate the line immediately, not wait for the next keystroke.
        transport, _auth, lines = self._harness()
        for byte in b"root":
            transport.dataReceived(bytes([byte]))
        self.assertEqual(lines, [])
        transport.dataReceived(b"\r")
        self.assertEqual(lines, [b"root"])

    def test_full_login_with_bare_cr(self) -> None:
        transport, auth, lines = self._harness()
        passwords: list[bytes] = []

        def spy_password(line: bytes) -> str:
            passwords.append(line)
            return "Discard"

        auth.telnet_Password = spy_password  # type: ignore[method-assign]

        transport.dataReceived(b"root\r")
        auth.state = "Password"
        transport.dataReceived(b"secret\r")
        self.assertEqual(lines, [b"root"])
        self.assertEqual(passwords, [b"secret"])

    def test_held_cr_not_flushed_after_login(self) -> None:
        # The CR handling is scoped to login. Once the interactive session
        # protocol is in place, a bare CR is left for Twisted's normal NVT
        # handling so the session's raw keystroke input is unaffected.
        transport = CowrieTelnetTransport()
        transport.transport = MagicMock()
        capture_events(transport)
        session = MagicMock()
        transport.protocol = session  # type: ignore[assignment]

        transport.dataReceived(b"x\r")

        self.assertEqual(transport.state, "newline")
        session.dataReceived.assert_called_once_with(b"x")


if __name__ == "__main__":
    unittest.main()
