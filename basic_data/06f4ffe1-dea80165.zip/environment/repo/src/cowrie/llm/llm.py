# SPDX-FileCopyrightText: 2025-2026 Michel Oosterhof <michel@oosterhof.net>
#
# SPDX-License-Identifier: BSD-3-Clause

# ABOUTME: LLM client for communicating with OpenAI-compatible APIs.
# ABOUTME: Sends shell commands to an LLM and returns simulated responses.

from __future__ import annotations

import json
import os
import urllib.parse
from typing import TYPE_CHECKING, Any

from twisted.internet import defer, protocol, reactor
from twisted.internet.defer import Deferred, inlineCallbacks
from twisted.internet.endpoints import HostnameEndpoint
from twisted.logger import Logger
from twisted.web.client import (
    Agent,
    HTTPConnectionPool,
    ProxyAgent,
    _HTTP11ClientFactory,  # pyright: ignore[reportPrivateUsage]
)
from twisted.web.http_headers import Headers
from twisted.web.iweb import IBodyProducer, IResponse
from zope.interface import implementer

from cowrie.core.config import CowrieConfig

if TYPE_CHECKING:
    from collections.abc import Generator

    from twisted.python import failure as tw_failure


@implementer(IBodyProducer)
class StringProducer:
    """
    Feeds a request body to the HTTP client.
    """

    def __init__(self, body: str) -> None:
        self.body = body.encode("utf-8")
        self.length = len(self.body)

    def startProducing(self, consumer):
        consumer.write(self.body)
        return defer.succeed(None)

    def pauseProducing(self) -> None:
        pass

    def resumeProducing(self) -> None:
        pass

    def stopProducing(self) -> None:
        pass


class SimpleResponseReceiver(protocol.Protocol):
    """
    Collects the response body from an HTTP response.
    """

    def __init__(self, status_code: int, d: defer.Deferred) -> None:
        self.status_code = status_code
        self.buf = b""
        self.d = d

    def dataReceived(self, data: bytes) -> None:
        self.buf += data

    def connectionLost(
        self, reason: tw_failure.Failure = protocol.connectionDone
    ) -> None:
        self.d.callback((self.status_code, self.buf))


class QuietHTTP11ClientFactory(_HTTP11ClientFactory):
    """
    Silences factory start/stop log messages.
    """

    noisy = False


class LLMClient:
    """
    Client for communicating with OpenAI-compatible LLM APIs.
    """

    _log = Logger()

    def __init__(self) -> None:
        self._conn_pool = HTTPConnectionPool(reactor)
        self._conn_pool._factory = QuietHTTP11ClientFactory  # pyright: ignore[reportPrivateUsage]

        self.api_key = CowrieConfig.get("llm", "api_key", fallback="")
        self.model = CowrieConfig.get("llm", "model", fallback="gpt-4o-mini")
        self.host = CowrieConfig.get("llm", "host", fallback="https://api.openai.com")
        self.path = CowrieConfig.get("llm", "path", fallback="/v1/chat/completions")
        self.max_tokens = CowrieConfig.getint("llm", "max_tokens", fallback=500)
        self.temperature = CowrieConfig.getfloat("llm", "temperature", fallback=0.7)
        self.debug = CowrieConfig.getboolean("llm", "debug", fallback=False)

        proxy_url = (
            os.environ.get("https_proxy")
            or os.environ.get("HTTPS_PROXY")
            or os.environ.get("http_proxy")
            or os.environ.get("HTTP_PROXY")
        )
        self.agent: Agent | ProxyAgent
        if proxy_url:
            parsed = urllib.parse.urlparse(proxy_url)
            proxy_endpoint = HostnameEndpoint(
                reactor, parsed.hostname or "localhost", parsed.port or 8080
            )
            self.agent = ProxyAgent(proxy_endpoint, reactor, pool=self._conn_pool)
            self._log.info(
                "LLM using proxy: {host}:{port}", host=parsed.hostname, port=parsed.port
            )
        else:
            self.agent = Agent(reactor, pool=self._conn_pool)
        self.is_anthropic = "anthropic.com" in self.host

        if not self.api_key:
            self._log.warn("WARNING: No LLM API key configured in [llm] section")

    def _build_headers(self) -> Headers:
        """Build HTTP headers with authentication."""
        if self.is_anthropic:
            return Headers(
                {
                    b"Content-Type": [b"application/json"],
                    b"x-api-key": [self.api_key.encode()],
                    b"anthropic-version": [b"2023-06-01"],
                }
            )
        return Headers(
            {
                b"Content-Type": [b"application/json"],
                b"Authorization": [f"Bearer {self.api_key}".encode()],
            }
        )

    def _format_request_body(self, prompt: list[str]) -> dict:
        """Structure the request body for the LLM API.

        Anthropic Messages API requires the system prompt as a top-level
        parameter; OpenAI uses a message with role 'system'.
        """
        system_prompt = prompt[0] if prompt else ""
        messages = []
        for message in prompt[1:]:
            if message.startswith("User:"):
                messages.append({"role": "user", "content": message[5:].strip()})
            elif message.startswith("System:"):
                messages.append({"role": "assistant", "content": message[7:].strip()})
            else:
                messages.append({"role": "user", "content": message})

        if self.is_anthropic:
            return {
                "model": self.model,
                "system": system_prompt,
                "messages": messages or [{"role": "user", "content": ""}],
                "max_tokens": self.max_tokens,
            }

        # OpenAI-compatible format
        return {
            "model": self.model,
            "messages": [{"role": "system", "content": system_prompt}, *messages],
            "max_tokens": self.max_tokens,
            "temperature": self.temperature,
        }

    def _handle_response_body(self, response: IResponse) -> Deferred[tuple[int, bytes]]:
        """Extract the response body from the HTTP response."""
        d: Deferred[tuple[int, bytes]] = defer.Deferred()
        response.deliverBody(SimpleResponseReceiver(response.code, d))
        return d

    def _handle_connection_error(self, err: tw_failure.Failure) -> tuple[int, bytes]:
        """Handle connection errors."""
        err.trap(Exception)
        return (500, err.getErrorMessage().encode("utf-8"))

    def _send_request(self, prompt: list[str]) -> Deferred[tuple[int, bytes]]:
        """Send request to the LLM API."""
        request_body = self._format_request_body(prompt)

        if self.debug:
            self._log.info(
                "LLM request: {request}", request=json.dumps(request_body, indent=2)
            )

        url = f"{self.host}{self.path}"
        d: Deferred[Any] = self.agent.request(
            b"POST",
            url.encode("utf-8"),
            headers=self._build_headers(),
            bodyProducer=StringProducer(json.dumps(request_body)),
        )

        d.addCallbacks(self._handle_response_body, self._handle_connection_error)
        return d

    @inlineCallbacks
    def get_response(self, prompt: list[str]) -> Generator[Deferred[Any], Any, str]:
        """
        Get a response from the LLM for the given prompt.

        Args:
            prompt: List of messages. First is system prompt, rest are
                    conversation history with "User:" and "System:" prefixes.

        Returns:
            The LLM's response text, or empty string on error.
        """
        status_code, response = yield self._send_request(prompt)

        if status_code != 200:
            self._log.error(
                "LLM API error (status {status}): {response}",
                status=status_code,
                response=response.decode("utf-8"),
            )
            return ""

        try:
            response_json = json.loads(response)
        except json.JSONDecodeError:
            self._log.failure("Failed to parse LLM response")
            return ""

        if self.debug:
            self._log.info(
                "LLM response: {response}",
                response=json.dumps(response_json, indent=2),
            )

        # OpenAI-compatible format
        if "choices" in response_json and len(response_json["choices"]) > 0:
            content: str = response_json["choices"][0]["message"]["content"]
            return content

        # Anthropic Messages API format
        if "content" in response_json and len(response_json["content"]) > 0:
            content = response_json["content"][0].get("text", "")
            return content

        self._log.error("Unexpected LLM response format: {response}", response=response)
        return ""
