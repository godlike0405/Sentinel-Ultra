# SPDX-FileCopyrightText: 2016, 2019 Thomas Nicholson <tnnich@googlemail.com> Guilherme Borges <guilhermerosasborges@gmail.com>
# SPDX-FileCopyrightText: 2021-2025 Michel Oosterhof <michel@oosterhof.net>
#
# SPDX-License-Identifier: BSD-3-Clause

from __future__ import annotations

import re
import struct
import time
import uuid
import zlib
from hashlib import md5

from twisted.conch.ssh import transport
from twisted.conch.ssh.common import getNS
from twisted.internet import reactor
from twisted.internet.endpoints import TCP4ClientEndpoint
from twisted.logger import Logger
from twisted.protocols.policies import TimeoutMixin
from twisted.python import failure, randbytes

from cowrie.core.config import CowrieConfig
from cowrie.core.events import EventLog, transport_events
from cowrie.core.utils import escape_nonprintable
from cowrie.ssh_proxy import client_transport
from cowrie.ssh_proxy.protocols import ssh


class FrontendSSHTransport(transport.SSHServerTransport, TimeoutMixin):
    """
    Represents a connection from the frontend (a client or attacker).
    When such connection is received, start the connection to the backend (the VM that will provide the session);
    at the same time, perform the userauth service via ProxySSHAuthServer (built-in Cowrie's mechanism).
    After both sides are authenticated, forward all things from one side to another.
    """

    _log = Logger()
    buf: bytes
    ourVersionString: bytes
    gotVersion: bool
    # The session's event emitter, bound in connectionMade when the running
    # application provides a dispatcher.
    events: EventLog | None = None

    # TODO merge this with HoneyPotSSHTransport(transport.SSHServerTransport, TimeoutMixin)
    # maybe create a parent class with common methods for the two
    def __init__(self):
        self.timeoutCount = 0

        self.sshParse = None
        self.disconnected = False  # what was this used for

        self.peer_ip = None
        self.peer_port: int = 0
        self.local_ip = None
        self.local_port: int = 0

        self.startTime = None
        self.transportId = None
        self.sessionno: str = ""

        self.pool_interface = None
        self.backendConnected = False
        self.frontendAuthenticated = False
        self.delayedPackets = []

        # only used when simple proxy (no pool) set
        self.backend_ip = None
        self.backend_port = None
        self.backend_local_ip = None
        self.backend_local_port = None

    def connectionMade(self):
        """
        Called when the connection is made to the other side.  We sent our
        version and the MSG_KEXINIT packet.
        """
        self.sshParse = ssh.SSH(self)
        self.transportId = uuid.uuid4().hex[:12]
        self.sessionno = f"S{self.transport.sessionno}"

        self.peer_ip = self.transport.getPeer().host
        self.peer_port = self.transport.getPeer().port + 1
        self.local_ip = self.transport.getHost().host
        self.local_port = self.transport.getHost().port

        self.events = transport_events(
            self.factory,
            self.transport,
            session=self.transportId,
            protocol="ssh",
        )

        self.transport.write(self.ourVersionString + b"\r\n")
        self.currentEncryptions = transport.SSHCiphers(
            b"none", b"none", b"none", b"none"
        )
        self.currentEncryptions.setKeys(b"", b"", b"", b"", b"", b"")

        # if we have a pool connect to it and later request a backend, else just connect to a simple backend
        # when pool is set we can just test self.pool_interface to the same effect of getting the CowrieConfig
        proxy_backend = CowrieConfig.get("proxy", "backend", fallback="simple")

        if proxy_backend == "pool":
            # request a backend
            d = self.factory.pool_handler.request_interface()
            d.addCallback(self.pool_connection_success)
            d.addErrback(self.pool_connection_error)
        else:
            # simply a proxy, no pool
            backend_ip = CowrieConfig.get("proxy", "backend_ssh_host")
            backend_port = CowrieConfig.getint("proxy", "backend_ssh_port")
            self.connect_to_backend(backend_ip, backend_port)

    def pool_connection_error(self, reason: failure.Failure) -> None:
        self._log.info(
            "Connection to backend pool refused: {error}", error=reason.value
        )
        if self.transport:
            self.transport.loseConnection()

    def pool_connection_success(self, pool_interface):
        self._log.info("Connected to backend pool")

        self.pool_interface = pool_interface
        self.pool_interface.set_parent(self)

        # now request a backend
        self.pool_interface.send_vm_request(self.peer_ip)

    def received_pool_data(self, operation, status, *data):
        if operation == b"r":
            honey_ip = data[0]
            snapshot = data[1]
            ssh_port = data[2]

            self._log.info(
                "Got backend data from pool: {honey_ip}:{ssh_port}",
                honey_ip=honey_ip.decode(),
                ssh_port=ssh_port,
            )
            self._log.info("Snapshot file: {snapshot}", snapshot=snapshot.decode())

            self.connect_to_backend(honey_ip, ssh_port)

    def backend_connection_error(self, reason: failure.Failure) -> None:
        if self.events:
            self.events.dispatch(
                "cowrie.proxy.backend_connect_error",
                "Connection to honeypot backend %(backend_ip)s:%(backend_port)s refused: %(error)s",
                backend_ip=self.backend_ip,
                backend_port=self.backend_port,
                error=reason.getErrorMessage(),
            )
        if self.transport:
            self.transport.loseConnection()

    def backend_connection_success(self, backendTransport):
        backend_host = backendTransport.transport.getHost()
        backend_peer = backendTransport.transport.getPeer()

        # Cache resolved endpoints for connectionLost logging
        self.backend_local_ip = backend_host.host
        self.backend_local_port = backend_host.port
        self.backend_ip = (
            backend_peer.host
        )  # Sets backend_ip to its IP if backend_ip was a hostname
        self.backend_port = backend_peer.port

        if self.events:
            self.events.dispatch(
                "cowrie.proxy.backend_connected",
                "Connected to honeypot backend %(backend_ip)s:%(backend_port)s from %(local_ip)s:%(local_port)s",
                backend_ip=backend_peer.host,
                backend_port=backend_peer.port,
                local_ip=backend_host.host,
                local_port=backend_host.port,
            )

        self.startTime = time.time()

        # this timeout is replaced with `interactive_timeout` in ssh.py
        self.setTimeout(
            CowrieConfig.getint("honeypot", "authentication_timeout", fallback=120)
        )

    def connect_to_backend(self, ip, port):
        # remember target so we can log consistently on success/failure
        self.backend_ip = ip
        self.backend_port = port

        # connection to the backend starts here
        client_factory = client_transport.BackendSSHFactory()
        client_factory.server = self

        point = TCP4ClientEndpoint(reactor, ip, port, timeout=10)
        d = point.connect(client_factory)
        d.addCallback(self.backend_connection_success)
        d.addErrback(self.backend_connection_error)

    def sendKexInit(self):
        """
        Don't send key exchange prematurely
        """
        if not self.gotVersion:
            return
        transport.SSHServerTransport.sendKexInit(self)

    def _unsupportedVersionReceived(self, remoteVersion):
        """
        Change message to be like OpenSSH
        """
        self.transport.write(b"Protocol major versions differ.\n")
        self.transport.loseConnection()

    def dataReceived(self, data: bytes) -> None:
        """
        First, check for the version string (SSH-2.0-*).  After that has been
        received, this method adds data to the buffer, and pulls out any
        packets.

        @type data: C{str}
        """
        self.buf += data

        # get version from start of communication; check if valid and supported by Twisted
        if not self.gotVersion:
            if b"\n" not in self.buf:
                return
            self.otherVersionString = self.buf.split(b"\n")[0].strip()
            if self.events:
                self.events.dispatch(
                    "cowrie.client.version",
                    "Remote SSH version: %(version)s",
                    version=escape_nonprintable(self.otherVersionString),
                )
            m = re.match(rb"SSH-(\d+.\d+)-(.*)", self.otherVersionString)
            if m is None:
                self._log.info(
                    "Bad protocol version identification: {version!r}",
                    version=self.otherVersionString,
                )
                if self.transport:
                    self.transport.write(b"Protocol mismatch.\n")
                    self.transport.loseConnection()
                return
            else:
                self.gotVersion = True
                remote_version = m.group(1)
                if remote_version not in self.supportedVersions:
                    self._unsupportedVersionReceived(None)
                    return
                i = self.buf.index(b"\n")
                self.buf = self.buf[i + 1 :]
                self.sendKexInit()
        packet = self.getPacket()
        while packet:
            messageNum = ord(packet[0:1])
            self.dispatchMessage(messageNum, packet[1:])
            packet = self.getPacket()

    def dispatchMessage(self, messageNum, payload):
        # overriden dispatchMessage sets services, we do that here too then
        # we're particularly interested in userauth, since Twisted does most of that for us
        if messageNum == 5:
            self.ssh_SERVICE_REQUEST(payload)
        elif 50 <= messageNum <= 79:  # userauth numbers
            self.frontendAuthenticated = False
            transport.SSHServerTransport.dispatchMessage(
                self, messageNum, payload
            )  # let userauth deal with it

        # TODO delay userauth until backend is connected?

        elif transport.SSHServerTransport.isEncrypted(self, "both"):
            self.packet_buffer(messageNum, payload)
        else:
            transport.SSHServerTransport.dispatchMessage(self, messageNum, payload)

    def sendPacket(self, messageType, payload):
        """
        Override because OpenSSH pads with 0 on KEXINIT
        """
        if self._keyExchangeState != self._KEY_EXCHANGE_NONE:
            if not self._allowedKeyExchangeMessageType(messageType):
                self._blockedByKeyExchange.append((messageType, payload))
                return

        payload = chr(messageType).encode() + payload
        if self.outgoingCompression:
            payload = self.outgoingCompression.compress(
                payload
            ) + self.outgoingCompression.flush(2)
        bs = self.currentEncryptions.encBlockSize
        # 4 for the packet length and 1 for the padding length
        totalSize = 5 + len(payload)
        lenPad = bs - (totalSize % bs)
        if lenPad < 4:
            lenPad = lenPad + bs
        if messageType == transport.MSG_KEXINIT:
            padding = b"\0" * lenPad
        else:
            padding = randbytes.secureRandom(lenPad)

        packet = struct.pack(b"!LB", totalSize + lenPad - 4, lenPad) + payload + padding
        encPacket = self.currentEncryptions.encrypt(
            packet
        ) + self.currentEncryptions.makeMAC(self.outgoingPacketSequence, packet)
        self.transport.write(encPacket)
        self.outgoingPacketSequence += 1

    def ssh_KEXINIT(self, packet):
        k = getNS(packet[16:], 10)
        strings, _ = k[:-1], k[-1]
        (kexAlgs, keyAlgs, encCS, _, macCS, _, compCS, _, langCS, _) = (
            s.split(b",") for s in strings
        )

        # hassh SSH client fingerprint
        # https://github.com/salesforce/hassh
        ckexAlgs = ",".join([alg.decode("utf-8") for alg in kexAlgs])
        cencCS = ",".join([alg.decode("utf-8") for alg in encCS])
        cmacCS = ",".join([alg.decode("utf-8") for alg in macCS])
        ccompCS = ",".join([alg.decode("utf-8") for alg in compCS])
        hasshAlgorithms = f"{ckexAlgs};{cencCS};{cmacCS};{ccompCS}"
        hassh = md5(hasshAlgorithms.encode("utf-8")).hexdigest()

        if self.events:
            self.events.dispatch(
                "cowrie.client.kex",
                "SSH client hassh fingerprint: %(hassh)s",
                hassh=hassh,
                hasshAlgorithms=hasshAlgorithms,
                kexAlgs=kexAlgs,
                keyAlgs=keyAlgs,
                encCS=encCS,
                macCS=macCS,
                compCS=compCS,
                langCS=langCS,
            )

        return transport.SSHServerTransport.ssh_KEXINIT(self, packet)

    def timeoutConnection(self):
        """
        Make sure all sessions time out eventually.
        Timeout is reset when authentication succeeds.
        """
        self._log.info("Timeout reached in FrontendSSHTransport")

        if self.transport:
            self.transport.loseConnection()

        if self.sshParse.client and self.sshParse.client.transport:
            self.sshParse.client.transport.loseConnection()

    def setService(self, service):
        """
        Remove login grace timeout, set zlib compression after auth
        """
        # when auth is successful we enable compression
        # this is called right after MSG_USERAUTH_SUCCESS
        if service.name == "ssh-connection":
            if self.outgoingCompressionType == "zlib@openssh.com":
                self.outgoingCompression = zlib.compressobj(6)
            if self.incomingCompressionType == "zlib@openssh.com":
                self.incomingCompression = zlib.decompressobj()

        transport.SSHServerTransport.setService(self, service)

    def connectionLost(self, reason=None):
        """
        This seems to be the only reliable place of catching lost connection
        """
        if self.backend_ip and self.backend_local_ip and self.events:
            self.events.dispatch(
                "cowrie.proxy.backend_disconnected",
                "Disconnected from honeypot backend %(backend_ip)s:%(backend_port)s (local %(local_ip)s:%(local_port)s)",
                backend_ip=self.backend_ip,
                backend_port=self.backend_port,
                local_ip=self.backend_local_ip,
                local_port=self.backend_local_port,
            )

        self.setTimeout(None)

        transport.SSHServerTransport.connectionLost(self, reason)

        self.transport.connectionLost(reason)
        self.transport = None

        # if connection from backend is not closed, do it here
        if self.sshParse.client and self.sshParse.client.transport:
            self.sshParse.client.transport.loseConnection()

        if self.pool_interface:
            # free VM from pool (VM was used if we performed SSH authentication to the backend)
            try:
                vm_dirty = (
                    self.sshParse.client.authDone if self.sshParse.client else False
                )
                self.pool_interface.send_vm_free(vm_dirty)
            except AttributeError:
                pass

            # close transport connection to pool
            self.pool_interface.transport.loseConnection()

        if self.startTime is not None:  # startTime is not set when auth fails
            duration_ms = round((time.time() - self.startTime) * 1000)
            if self.events is not None:
                self.events.session_closed(duration_ms)
        if self.events is not None:
            self.events.close()

    def sendDisconnect(self, reason, desc):
        """
        http://kbyte.snowpenguin.org/portal/2013/04/30/kippo-protocol-mismatch-workaround/
        Workaround for the "bad packet length" error message.

        @param reason: the reason for the disconnect.  Should be one of the
                       DISCONNECT_* values.
        @type reason: C{int}
        @param desc: a description of the reason for the disconnection.
        @type desc: C{str}
        """
        if b"bad packet length" not in desc:
            # With python >= 3 we can use super?
            transport.SSHServerTransport.sendDisconnect(self, reason, desc)
        else:
            self.transport.write(b"Packet corrupt\n")
            self._log.info(
                "Disconnecting with error, code {code}\nreason: {desc}",
                code=reason,
                desc=desc,
            )
            self.transport.loseConnection()

    def receiveError(self, reasonCode: str, description: str) -> None:
        """
        Called when we receive a disconnect error message from the other
        side.

        @param reasonCode: the reason for the disconnect, one of the
                           DISCONNECT_ values.
        @type reasonCode: L{int}
        @param description: a human-readable description of the
                            disconnection.
        @type description: L{str}
        """
        self._log.info(
            "Got remote error, code {code} reason: {description}",
            code=reasonCode,
            description=description,
        )

    def packet_buffer(self, messageNum: int, payload: bytes) -> None:
        """
        We have to wait until we have a connection to the backend is ready. Meanwhile, we hold packets from client
        to server in here.
        """
        if not self.backendConnected:
            # wait till backend connects to send packets to them
            self._log.debug(
                "Connection to backend not ready, buffering packet from frontend"
            )
            self.delayedPackets.append([messageNum, payload])
        else:
            if len(self.delayedPackets) > 0:
                # Flush the queued packets in order, then this one; leaving them
                # queued would strand a frontend request (e.g. the channel open
                # that follows login) and hang the session. Mirrors the backend
                # side in BackendSSHTransport.packet_buffer.
                self.delayedPackets.append([messageNum, payload])
                for packet in self.delayedPackets:
                    self.sshParse.parse_num_packet("[SERVER]", packet[0], packet[1])
                self.delayedPackets = []
            else:
                self.sshParse.parse_num_packet("[SERVER]", messageNum, payload)
