#!/usr/bin/env bash
set -euo pipefail
cd /app
if git apply -p1 --check --whitespace=nowarn /solution/golden.patch 2>/dev/null; then
  git apply -p1 --whitespace=nowarn /solution/golden.patch
elif git apply -p1 --reverse --check --whitespace=nowarn /solution/golden.patch 2>/dev/null; then
  # The oracle is already present. Idempotent reruns are successful no-ops.
  exit 0
else
  echo "golden.patch is neither applicable nor already applied" >&2
  exit 1
fi
