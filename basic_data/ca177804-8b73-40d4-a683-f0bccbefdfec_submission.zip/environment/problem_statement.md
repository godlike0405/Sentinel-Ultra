## Background

`wut` is a toolchain/library for building Wii U homebrew. Right now every C
allocation in a `wut` program goes through `wutmalloc`, which is a thin wrapper
over the CafeOS default heap (`MEMAllocFromDefaultHeap` /
`MEMAllocFromDefaultHeapEx` / `MEMFreeToDefaultHeap`). That heap is slow once a
program allocates heavily, and profiling on real hardware shows large slowdowns
compared to the custom heaps that retail games ship. We want C allocations to be
served by newlib's own `malloc`, backed by an `sbrk` region carved out of MEM2,
which is several times faster.

## What to change

Move RPX executables off the CafeOS default heap and onto a newlib-backed heap,
without changing any externally observable allocation behavior: allocations must
still succeed, `free` must release memory, and alignment requested through
`memalign` must be honored.

Concretely, the desired end state is:

- **A newlib-backed default heap.** Introduce a small `wutdefaultheap` component
  that redirects the CafeOS default-heap function pointers at the newlib
  allocator, so code calling `MEMAllocFromDefaultHeap` /
  `MEMAllocFromDefaultHeapEx` / `MEMFreeToDefaultHeap` ends up in `malloc` /
  `memalign` / `free`. It needs to be built and linked as part of the library.

- **RPX startup wiring.** RPX modules get a chance to run setup before any
  allocation happens, through a weakly-linked `__preinit_user` hook that the RPX
  crt0 exports for the loader to call. The default implementation should claim
  the MEM2 heap for `sbrk`, bring up the malloc lock, and install the
  newlib-backed default-heap wrappers. Because the hook is weak, a program can
  provide its own `__preinit_user` to opt out (for example, to fall back to the
  old `wutmalloc` behavior); that override must keep working.

- **RPL stays on wutmalloc.** RPL modules don't get `__preinit_user` and must not
  touch the default heap, so they keep using `wutmalloc`, allocating from
  whatever heap the RPX already set up. The RPL crt0 is responsible for bringing
  up `wutmalloc` during load. As a consequence, the common runtime init in
  `wut_crt.c` should no longer initialize `wutmalloc` unconditionally — that is
  now the RPX preinit's job for RPX and the RPL crt0's job for RPL.

- **sbrk over the whole heap.** The `sbrk` heap initializer should take the heap
  to allocate from as a parameter and reserve all of that heap's allocatable
  space, instead of relying on a compile-time size cap. The old fixed-size limit
  mechanism should be dropped entirely.

- **Faster locking.** newlib's malloc lock is currently an `OSMutex`. Since the
  critical sections are tiny, switch it to an uninterruptible spin lock to cut
  the locking overhead.

- **newlib syscalls.** Wire newlib up to the new heap and lock: newlib needs
  `sbrk` and malloc lock/unlock syscall entry points that forward to `wut`'s
  implementations, and the `sbrk` heap should be finalized during newlib
  teardown.

## Interface notes

These names are fixed by the platform ABI, newlib, or existing `wut`
conventions, so use them as given:

- `__preinit_user` — weak hook, exported from `libraries/wutcrt/crt0_rpx.s`.
- `__init_wut_defaultheap` — installs the default-heap wrappers.
- `__init_wut_sbrk_heap(MEMHeapHandle heapHandle)` — sets up the `sbrk` region
  over the given heap.
- `__init_wut_malloc` — the legacy `wutmalloc` bring-up, still used by RPL.
- newlib syscall wrappers `__syscall_sbrk_r`, `__syscall_malloc_lock`,
  `__syscall_malloc_unlock`.
- The spin-lock API lives in `<coreinit/spinlock.h>` (`OSSpinLock`,
  `OSInitSpinLock`, `OSUninterruptibleSpinLock_Acquire`,
  `OSUninterruptibleSpinLock_Release`).

New sources should live under `libraries/` alongside the components they belong
to (`wutdefaultheap`, `wutcrt`).

## Build

`wut` is built with the devkitPPC toolchain via its top-level `Makefile`:

```
make -j"$(nproc)" && make install
```

The new and changed sources must compile with that toolchain, and the new
source directory has to be wired into the build.
