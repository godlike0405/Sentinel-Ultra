void
WHBInitializeSocketLibrary()
{
}

void
WHBDeinitializeSocketLibrary()
{
}
