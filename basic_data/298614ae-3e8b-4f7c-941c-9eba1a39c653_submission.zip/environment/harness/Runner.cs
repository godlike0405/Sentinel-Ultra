using System;
using System.Linq;
using System.Reflection;
using NUnit.Framework;

// Tiny NUnit-style runner: finds [TestFixture] classes in this assembly, runs
// their [SetUp]/[Test]/[TearDown] methods, and prints one line per test that
// the verifier parses ("PASS <fully.qualified.name>" / "FAIL <...>").
internal static class Runner
{
    private static int Main()
    {
        int failures = 0;

        foreach (Type fixture in Assembly.GetExecutingAssembly().GetTypes())
        {
            if (fixture.GetCustomAttribute<TestFixtureAttribute>() == null)
            {
                continue;
            }

            MethodInfo[] methods = fixture.GetMethods(BindingFlags.Public | BindingFlags.Instance);
            MethodInfo[] setUps = methods.Where(m => m.GetCustomAttribute<SetUpAttribute>() != null).ToArray();
            MethodInfo[] tearDowns = methods.Where(m => m.GetCustomAttribute<TearDownAttribute>() != null).ToArray();

            foreach (MethodInfo test in methods.Where(m => m.GetCustomAttribute<TestAttribute>() != null))
            {
                string name = fixture.FullName + "." + test.Name;
                object instance = Activator.CreateInstance(fixture);

                try
                {
                    foreach (MethodInfo setUp in setUps)
                    {
                        setUp.Invoke(instance, null);
                    }

                    test.Invoke(instance, null);
                    Console.WriteLine("PASS " + name);
                }
                catch (Exception ex)
                {
                    Exception cause = (ex as TargetInvocationException)?.InnerException ?? ex;
                    Console.WriteLine("FAIL " + name);
                    Console.Error.WriteLine($"{name}: {cause.GetType().Name}: {cause.Message}");
                    failures++;
                }
                finally
                {
                    foreach (MethodInfo tearDown in tearDowns)
                    {
                        try
                        {
                            tearDown.Invoke(instance, null);
                        }
                        catch
                        {
                            // teardown failures shouldn't mask the test result
                        }
                    }
                }
            }
        }

        return failures == 0 ? 0 : 1;
    }
}
