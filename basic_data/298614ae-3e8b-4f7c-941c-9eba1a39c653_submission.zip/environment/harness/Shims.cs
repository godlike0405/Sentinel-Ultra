// Minimal stand-ins for the Unity and NUnit types the comparer test touches.
// The comparer's ordering logic is plain C#; the only Unity coupling is the
// UnityEngine.Object generic constraint plus .name / GetInstanceID(), so a tiny
// shim lets us exercise the real production code without a Unity install.

namespace UnityEngine
{
    public class Object
    {
        private static int _nextId = 1000;
        private readonly int _instanceId;

        public Object()
        {
            _instanceId = ++_nextId;
        }

        public string name { get; set; }

        public int GetInstanceID() => _instanceId;

        public static void DestroyImmediate(Object obj) { }
    }

    public class GameObject : Object
    {
        public GameObject() { }

        public GameObject(string name)
        {
            this.name = name;
        }
    }
}

namespace NUnit.Framework
{
    using System;

    [AttributeUsage(AttributeTargets.Class)]
    public sealed class TestFixtureAttribute : Attribute { }

    [AttributeUsage(AttributeTargets.Method)]
    public sealed class TestAttribute : Attribute { }

    [AttributeUsage(AttributeTargets.Method)]
    public sealed class SetUpAttribute : Attribute { }

    [AttributeUsage(AttributeTargets.Method)]
    public sealed class TearDownAttribute : Attribute { }

    public class AssertionException : Exception
    {
        public AssertionException(string message) : base(message) { }
    }

    public static class Assert
    {
        public static void Less(int actual, int expected)
        {
            if (!(actual < expected))
            {
                throw new AssertionException($"Expected {actual} to be less than {expected}");
            }
        }

        public static void Greater(int actual, int expected)
        {
            if (!(actual > expected))
            {
                throw new AssertionException($"Expected {actual} to be greater than {expected}");
            }
        }
    }
}
