﻿namespace WallstopStudios.UnityHelpers.Editor.CustomEditors
{
#if UNITY_EDITOR
    using UnityEditor;
    using UnityEngine;
    using Core.Extension;
    using WallstopStudios.UnityHelpers.Utils;

    [CustomEditor(typeof(MatchColliderToSprite))]
    public sealed class MatchColliderToSpriteEditor : Editor
    {
        public override void OnInspectorGUI()
        {
            base.OnInspectorGUI();

            MatchColliderToSprite matchColliderToSprite = target as MatchColliderToSprite;
            if (matchColliderToSprite == null)
            {
                this.LogError(
                    $"Target was of type {target?.GetType()}, expected {nameof(MatchColliderToSprite)}."
                );
                return;
            }

            if (GUILayout.Button("MatchColliderToSprite"))
            {
                matchColliderToSprite.OnValidate();
            }
        }
    }
#endif
}
