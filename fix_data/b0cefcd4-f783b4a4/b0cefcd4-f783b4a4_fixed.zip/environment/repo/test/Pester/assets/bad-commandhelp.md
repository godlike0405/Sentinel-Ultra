echo # Bad Help
