//! Easily export your Rust types to other languages
//!
//! This crate contains the macro which are reexported by the `specta` crate.
//! You shouldn't need to use this crate directly.
//! Checkout [Specta](https://docs.rs/specta).
#![doc(
    html_logo_url = "https://github.com/specta-rs/specta/raw/main/.github/logo-128.png",
    html_favicon_url = "https://github.com/specta-rs/specta/raw/main/.github/logo-128.png"
)]

#[cfg(feature = "DO_NOT_USE_function")]
mod specta;
mod r#type;
mod utils;

use quote::quote;
use syn::{Error, LitStr, Type, parse_macro_input};

/// Implements `specta::Type` for a given struct or enum.
///
/// # Attributes
/// Attributes can be applied to modify Specta's behavior. Specta can natively read `#[serde(...)]` attributes so your generally recommend to [just use them](https://serde.rs/attributes.html).
///
/// Specta also introduces some of it's own attributes:
///  - `#[specta(optional)]` - When paired with an `Option<T>` field, this will result in `{ a?: T | null }` instead of `{ a: T | null }`.
///  - `#[specta(type = ::std::string::String)]` - Will override the type of a item, variant or field to a given type.
///  - `#[specta(collect = false)]` - When using the `collect` feature, this will prevent the specific type from being exported.
///
/// # Format parser discovery
///
/// Specta macros discover format parser crates at macro-expansion time.
///
/// - `specta-serde` is discovered automatically when it exists in the current
///   crate dependency graph.
/// - Additional parser crates can be registered globally with the
///   `SPECTA_FORMAT_CRATES` environment variable as a comma-separated list.
///
/// A common way to set this is from your crate's `build.rs`:
/// ```rust,ignore
/// fn main() {
///     println!("cargo:rustc-env=SPECTA_FORMAT_CRATES=my-format-parser,another-parser");
/// }
/// ```
///
/// Entries are resolved as Cargo package names first (rename-safe). If package
/// resolution fails, entries are treated as Rust paths.
///
/// ## Example
///
/// ```ignore
/// use specta::Type;
///
/// // Use it on structs
/// #[derive(Type)]
/// pub struct MyCustomStruct {
///     pub name: String,
/// }
///
/// #[derive(Type)]
/// pub struct MyCustomStruct2(String, i32, bool);
///
/// // Use it on enums
/// #[derive(Type)]
/// pub enum MyCustomType {
///     VariantOne,
///     VariantTwo(String, i32),
///     VariantThree { name: String, age: i32 },
/// }
/// ```
#[proc_macro_derive(Type, attributes(specta))]
pub fn derive_type(input: proc_macro::TokenStream) -> proc_macro::TokenStream {
    r#type::derive(input).unwrap_or_else(|err| err.into_compile_error().into())
}

/// Parses a string literal into a Rust type token stream.
///
/// This is an internal helper proc macro used by Specta macros to turn a
/// literal like `"Option<String>"` into a Rust type at compile time.
#[proc_macro]
pub fn parse_type_from_lit(input: proc_macro::TokenStream) -> proc_macro::TokenStream {
    let lit = parse_macro_input!(input as LitStr);

    match syn::parse_str::<Type>(&lit.value()) {
        Ok(ty) => quote!(#ty).into(),
        Err(err) => Error::new_spanned(lit, format!("invalid type literal: {err}"))
            .to_compile_error()
            .into(),
    }
}

/// Prepares a function to have its types extracted using `specta::function::fn_datatype!`
///
/// ## Example
///
/// ```ignore
/// #[specta::specta]
/// fn my_function(arg1: i32, arg2: bool) -> &'static str {
///     "Hello World"
/// }
/// ```
#[proc_macro_attribute]
#[cfg(feature = "DO_NOT_USE_function")]
pub fn specta(
    _: proc_macro::TokenStream,
    item: proc_macro::TokenStream,
) -> proc_macro::TokenStream {
    specta::attribute(item).unwrap_or_else(|err| err.into_compile_error().into())
}
