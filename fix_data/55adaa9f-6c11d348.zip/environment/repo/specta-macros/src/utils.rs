use proc_macro2::Span;
use quote::ToTokens;
use syn::{
    Expr, Ident, Lit, Meta, Path, Result, Token, Type, TypePath,
    ext::IdentExt,
    parse::{Parse, ParseStream},
    spanned::Spanned,
    token::Paren,
};

#[derive(Clone)]
pub enum AttributeValue {
    /// Literal value. Eg. `#[specta(name = "hello")]` or `#[specta(name = u32)]`
    Lit(Lit),
    /// Path value. Eg. `#[specta(type = String)]` or `#[specta(type = ::std::string::String)]`
    /// Path doesn't follow the Rust spec hence the need for this custom parser. We are doing this anyway for backwards compatibility.
    Path(Path),
    /// Expression value for values that are not valid paths.
    /// This allows us to later parse richer forms such as tuple/array/reference types.
    Expr(Expr),
    /// A nested attribute. Eg. the `deprecated(note = "some note") in `#[specta(deprecated(note = "some note"))]`
    Attribute { span: Span, attr: Vec<Attribute> },
}

impl AttributeValue {
    fn span(&self) -> Span {
        match self {
            Self::Lit(lit) => lit.span(),
            Self::Path(path) => path.span(),
            Self::Expr(expr) => expr.span(),
            Self::Attribute { span, .. } => *span,
        }
    }
}

impl Parse for AttributeValue {
    fn parse(input: ParseStream) -> Result<Self> {
        Ok(match input.peek(Lit) {
            true => Self::Lit(input.parse()?),
            false => {
                if input.fork().parse::<Path>().is_ok() {
                    Self::Path(input.parse()?)
                } else {
                    Self::Expr(input.parse()?)
                }
            }
        })
    }
}

#[derive(Clone)]
pub struct Attribute {
    /// Source of the attribute. Eg. `specta`, `serde`, `repr`, `deprecated`, etc.
    pub source: String,
    /// Key of the current item. Eg. `specta` or `type`in `#[specta(type = String)]`
    pub key: Ident,
    /// Value of the item. Eg. `String` in `#[specta(type = String)]`
    pub value: Option<AttributeValue>,
}

impl Attribute {
    /// Span of they value. Eg. `String` in `#[specta(type = String)]`
    /// Will fallback to the key span if no value is present.
    pub fn value_span(&self) -> Span {
        match &self.value {
            Some(v) => v.span(),
            None => self.key.span(),
        }
    }

    pub fn parse_string(&self) -> Result<String> {
        match &self.value {
            Some(AttributeValue::Lit(Lit::Str(string))) => Ok(string.value()),
            _ => Err(syn::Error::new(
                self.value_span(),
                "specta: expected string literal. Eg. `\"somestring\"`",
            )),
        }
    }

    pub fn parse_bool(&self) -> Result<bool> {
        match &self.value {
            Some(AttributeValue::Lit(Lit::Bool(b))) => Ok(b.value()),
            _ => Err(syn::Error::new(
                self.value_span(),
                "specta: expected boolean literal. Eg. `true` or `false`",
            )),
        }
    }

    pub fn parse_path(&self) -> Result<Path> {
        match &self.value {
            Some(AttributeValue::Path(path)) => Ok(path.clone()),
            Some(AttributeValue::Expr(Expr::Path(path))) => Ok(path.path.clone()),
            _ => Err(syn::Error::new(
                self.value_span(),
                "specta: expected path. Eg. `String` or `std::string::String`",
            )),
        }
    }

    pub fn parse_type(&self) -> Result<Type> {
        match &self.value {
            Some(AttributeValue::Path(path)) => Ok(Type::Path(TypePath {
                qself: None,
                path: path.clone(),
            })),
            Some(AttributeValue::Expr(expr)) => syn::parse2(expr.to_token_stream()).map_err(|_| {
                syn::Error::new(
                    self.value_span(),
                    "specta: expected type. Eg. `String`, `(String, i32)` or `Vec<T>`",
                )
            }),
            _ => Err(syn::Error::new(
                self.value_span(),
                "specta: expected type. Eg. `String`, `(String, i32)` or `Vec<T>`",
            )),
        }
    }
}

pub trait AttrExtract {
    fn extract(&mut self, source: &str, key: &str) -> Option<Attribute>;
    fn extract_all(&mut self, source: &str, key: &str) -> Vec<Attribute>;
}

impl AttrExtract for Vec<Attribute> {
    fn extract(&mut self, source: &str, key: &str) -> Option<Attribute> {
        // 1. Check for top-level match (e.g., #[deprecated])
        if let Some(pos) = self
            .iter()
            .position(|attr| attr.source == source && attr.key == key)
        {
            return Some(self.swap_remove(pos));
        }

        // 2. Check nested attributes within parent matching source
        //    e.g., extract("specta", "inline") from #[specta(inline)]
        //    Structure: Attribute { source: "specta", key: "specta", value: Attribute { key: "inline" } }
        for i in 0..self.len() {
            if self[i].source == source
                && self[i].key == source
                && let Some(AttributeValue::Attribute {
                    attr: nested_attrs, ..
                }) = &mut self[i].value
                && let Some(nested_pos) = nested_attrs.iter().position(|a| a.key == key)
            {
                let result = nested_attrs.swap_remove(nested_pos);

                // If parent attribute is now empty, remove it too
                if nested_attrs.is_empty() {
                    self.swap_remove(i);
                }

                return Some(result);
            }
        }

        None
    }

    fn extract_all(&mut self, source: &str, key: &str) -> Vec<Attribute> {
        let mut result = Vec::new();

        // 1. Extract all top-level matches
        let mut i = 0;
        while i < self.len() {
            if self[i].source == source && self[i].key == key {
                result.push(self.swap_remove(i));
                // Don't increment i, as swap_remove moved a new element to position i
            } else {
                i += 1;
            }
        }

        // 2. Extract all nested matches
        let mut i = 0;
        while i < self.len() {
            let mut should_remove_parent = false;

            if self[i].source == source
                && self[i].key == source
                && let Some(AttributeValue::Attribute {
                    attr: nested_attrs, ..
                }) = &mut self[i].value
            {
                let mut j = 0;
                while j < nested_attrs.len() {
                    if nested_attrs[j].key == key {
                        result.push(nested_attrs.swap_remove(j));
                    } else {
                        j += 1;
                    }
                }

                should_remove_parent = nested_attrs.is_empty();
            }

            if should_remove_parent {
                self.swap_remove(i);
            } else {
                i += 1;
            }
        }

        result
    }
}

struct NestedAttributeList {
    attrs: Vec<Attribute>,
}

impl Parse for NestedAttributeList {
    fn parse(input: ParseStream) -> Result<Self> {
        let mut attrs = Vec::new();
        while !input.is_empty() {
            if input.peek(Ident::peek_any) {
                let fork = input.fork();
                let _ = fork.call(Ident::parse_any)?;

                if fork.peek(Token![::]) {
                    let _ignored: syn::Expr = input.parse()?;
                } else {
                    let key = input.call(Ident::parse_any)?;
                    let key_span = key.span();

                    attrs.push(Attribute {
                        source: String::new(),
                        key,
                        value: match false {
                            _ if input.peek(Paren) => {
                                let content;
                                syn::parenthesized!(content in input);
                                Some(AttributeValue::Attribute {
                                    span: key_span,
                                    attr: content.parse::<NestedAttributeList>()?.attrs,
                                })
                            }
                            _ if input.peek(Token![=]) => {
                                input.parse::<Token![=]>()?;
                                Some(input.parse()?)
                            }
                            _ => None,
                        },
                    });
                }
            } else {
                let _ignored: syn::Expr = input.parse()?;
            }

            if input.peek(Token![,]) {
                input.parse::<Token![,]>()?;
            }
        }
        Ok(NestedAttributeList { attrs })
    }
}

/// pass all of the attributes into a single structure.
/// We can then remove them from the struct while passing an any left over must be invalid and an error can be thrown.
pub fn parse_attrs(attrs: &[syn::Attribute]) -> syn::Result<Vec<Attribute>> {
    parse_attrs_with_filter(attrs, &[])
}

/// Same as `parse_attrs` but allows skipping attributes by name.
/// This is useful for skipping attributes that may have non-standard syntax that we can't parse.
pub fn parse_attrs_with_filter(
    attrs: &[syn::Attribute],
    skip_attrs: &[String],
) -> syn::Result<Vec<Attribute>> {
    let mut result = Vec::new();

    for attr in attrs {
        let ident = attr
            .path()
            .segments
            .last()
            .expect("Attribute path must have at least one segment")
            .clone()
            .ident;

        // Skip attributes that are in the skip list
        let attr_name = ident.to_string();
        if skip_attrs.contains(&attr_name) {
            continue;
        }

        result.append(&mut match &attr.meta {
            Meta::Path(_) => vec![Attribute {
                source: attr_name.clone(),
                key: ident.clone(),
                value: None,
            }],
            Meta::List(meta) => {
                let source = attr_name.clone();
                let mut parsed: Vec<Attribute> =
                    syn::parse2::<NestedAttributeList>(meta.tokens.clone())?.attrs;
                for a in &mut parsed {
                    a.source = source.clone();
                }
                vec![Attribute {
                    source,
                    key: ident.clone(),
                    value: Some(AttributeValue::Attribute {
                        span: ident.span(),
                        attr: parsed,
                    }),
                }]
            }
            Meta::NameValue(meta) => {
                let source = attr_name.clone();
                let mut parsed: Vec<Attribute> =
                    syn::parse2::<NestedAttributeList>(meta.to_token_stream().clone())?.attrs;
                for a in &mut parsed {
                    a.source = source.clone();
                }
                parsed
            }
        });
    }

    Ok(result)
}

pub fn unraw_raw_ident(ident: &Ident) -> String {
    let ident = ident.to_string();
    if ident.starts_with("r#") {
        ident.trim_start_matches("r#").to_owned()
    } else {
        ident
    }
}

#[cfg(feature = "DO_NOT_USE_function")]
pub fn format_fn_wrapper(function: &Ident) -> Ident {
    quote::format_ident!("__specta__fn__{}", function)
}
