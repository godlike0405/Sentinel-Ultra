use crate::datatype::{Attributes, DataType, Fields};

use super::StructBuilder;

use super::{NamedFields, UnnamedFields};

/// represents a Rust [struct](https://doc.rust-lang.org/std/keyword.struct.html).
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct Struct {
    pub(crate) fields: Fields,
    pub(crate) attributes: Attributes,
}

// Do not implement `Default` for `Struct` as it's unclear what that would be. `Unit`, yes but still.

impl Struct {
    /// Construct a new unit struct.
    pub fn unit() -> Self {
        Self {
            fields: Fields::Unit,
            attributes: Default::default(),
        }
    }

    /// Construct a named struct.
    pub fn named() -> StructBuilder<NamedFields> {
        StructBuilder {
            fields: NamedFields {
                fields: Default::default(),
            },
        }
    }

    /// Construct an unnamed struct.
    pub fn unnamed() -> StructBuilder<UnnamedFields> {
        StructBuilder {
            fields: UnnamedFields {
                fields: Default::default(),
            },
        }
    }

    /// Get a immutable reference to the fields of the struct.
    pub fn fields(&self) -> &Fields {
        &self.fields
    }

    /// Get a mutable reference to the fields of the struct.
    pub fn fields_mut(&mut self) -> &mut Fields {
        &mut self.fields
    }

    /// Set the fields of the struct.
    pub fn set_fields(&mut self, fields: Fields) {
        self.fields = fields;
    }

    /// Get a immutable reference to the attributes of the struct.
    pub fn attributes(&self) -> &Attributes {
        &self.attributes
    }

    /// Get a mutable reference to the attributes of the struct.
    pub fn attributes_mut(&mut self) -> &mut Attributes {
        &mut self.attributes
    }
}

impl From<Struct> for DataType {
    fn from(t: Struct) -> Self {
        Self::Struct(t)
    }
}
