/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied.  See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package org.apache.commons.lang3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.lang.reflect.Modifier;
import java.util.Set;

import org.junit.jupiter.api.Test;

/**
 * Tests {@link CharSet}.
 */
class CharSetTest extends AbstractLangTest {

    @Test
    void testClass() {
        assertTrue(Modifier.isPublic(CharSet.class.getModifiers()));
        assertFalse(Modifier.isFinal(CharSet.class.getModifiers()));
    }

    @Test
    void testConstructor_String_combo() {
        CharSet set;
        Set<CharRange> array;

        set = CharSet.getInstance("abc");
        array = set.getCharRanges();
        assertEquals(3, array.size());
        assertTrue(array.contains(CharRange.is('a')));
        assertTrue(array.contains(CharRange.is('b')));
        assertTrue(array.contains(CharRange.is('c')));

        set = CharSet.getInstance("a-ce-f");
        array = set.getCharRanges();
        assertEquals(2, array.size());
        assertTrue(array.contains(CharRange.isIn('a', 'c')));
        assertTrue(array.contains(CharRange.isIn('e', 'f')));

        set = CharSet.getInstance("ae-f");
        array = set.getCharRanges();
        assertEquals(2, array.size());
        assertTrue(array.contains(CharRange.is('a')));
        assertTrue(array.contains(CharRange.isIn('e', 'f')));

        set = CharSet.getInstance("e-fa");
        array = set.getCharRanges();
        assertEquals(2, array.size());
        assertTrue(array.contains(CharRange.is('a')));
        assertTrue(array.contains(CharRange.isIn('e', 'f')));

        set = CharSet.getInstance("ae-fm-pz");
        array = set.getCharRanges();
        assertEquals(4, array.size());
        assertTrue(array.contains(CharRange.is('a')));
        assertTrue(array.contains(CharRange.isIn('e', 'f')));
        assertTrue(array.contains(CharRange.isIn('m', 'p')));
        assertTrue(array.contains(CharRange.is('z')));
    }

    @Test
    void testConstructor_String_comboNegated() {
        CharSet set;
        Set<CharRange> array;

        set = CharSet.getInstance("^abc");
        array = set.getCharRanges();
        assertEquals(3, array.size());
        assertTrue(array.contains(CharRange.isNot('a')));
        assertTrue(array.contains(CharRange.is('b')));
        assertTrue(array.contains(CharRange.is('c')));

        set = CharSet.getInstance("b^ac");
        array = set.getCharRanges();
        assertEquals(3, array.size());
        assertTrue(array.contains(CharRange.is('b')));
        assertTrue(array.contains(CharRange.isNot('a')));
        assertTrue(array.contains(CharRange.is('c')));

        set = CharSet.getInstance("db^ac");
        array = set.getCharRanges();
        assertEquals(4, array.size());
        assertTrue(array.contains(CharRange.is('d')));
        assertTrue(array.contains(CharRange.is('b')));
        assertTrue(array.contains(CharRange.isNot('a')));
        assertTrue(array.contains(CharRange.is('c')));

        set = CharSet.getInstance("^b^a");
        array = set.getCharRanges();
        assertEquals(2, array.size());
        assertTrue(array.contains(CharRange.isNot('b')));
        assertTrue(array.contains(CharRange.isNot('a')));

        set = CharSet.getInstance("b^a-c^z");
        array = set.getCharRanges();
        assertEquals(3, array.size());
        assertTrue(array.contains(CharRange.isNotIn('a', 'c')));
        assertTrue(array.contains(CharRange.isNot('z')));
        assertTrue(array.contains(CharRange.is('b')));
    }

    @Test
    void testConstructor_String_oddCombinations() {
        CharSet set;
        Set<CharRange> array;

        set = CharSet.getInstance("a-^c");
        array = set.getCharRanges();
        assertTrue(array.contains(CharRange.isIn('a', '^'))); // "a-^"
        assertTrue(array.contains(CharRange.is('c'))); // "c"
        assertFalse(set.contains('b'));
        assertTrue(set.contains('^'));
        assertTrue(set.contains('_')); // between ^ and a
        assertTrue(set.contains('c'));

        set = CharSet.getInstance("^a-^c");
        array = set.getCharRanges();
        assertTrue(array.contains(CharRange.isNotIn('a', '^'))); // "^a-^"
        assertTrue(array.contains(CharRange.is('c'))); // "c"
        assertTrue(set.contains('b'));
        assertFalse(set.contains('^'));
        assertFalse(set.contains('_')); // between ^ and a

        set = CharSet.getInstance("a- ^-- "); //contains everything
        array = set.getCharRanges();
        assertTrue(array.contains(CharRange.isIn('a', ' '))); // "a- "
        assertTrue(array.contains(CharRange.isNotIn('-', ' '))); // "^-- "
        assertTrue(set.contains('#'));
        assertTrue(set.contains('^'));
        assertTrue(set.contains('a'));
        assertTrue(set.contains('*'));
        assertTrue(set.contains('A'));

        set = CharSet.getInstance("^-b");
        array = set.getCharRanges();
        assertTrue(array.contains(CharRange.isIn('^', 'b'))); // "^-b"
        assertTrue(set.contains('b'));
        assertTrue(set.contains('_')); // between ^ and a
        assertFalse(set.contains('A'));
        assertTrue(set.contains('^'));

        set = CharSet.getInstance("b-^");
        array = set.getCharRanges();
        assertTrue(array.contains(CharRange.isIn('^', 'b'))); // "b-^"
        assertTrue(set.contains('b'));
        assertTrue(set.contains('^'));
        assertTrue(set.contains('a')); // between ^ and b
        assertFalse(set.contains('c'));
    }

    @Test
    void testConstructor_String_oddDash() {
        CharSet set;
        Set<CharRange> array;

        set = CharSet.getInstance("-");
        array = set.getCharRanges();
        assertEquals(1, array.size());
        assertTrue(array.contains(CharRange.is('-')));

        set = CharSet.getInstance("--");
        array = set.getCharRanges();
        assertEquals(1, array.size());
        assertTrue(array.contains(CharRange.is('-')));

        set = CharSet.getInstance("---");
        array = set.getCharRanges();
        assertEquals(1, array.size());
        assertTrue(array.contains(CharRange.is('-')));

        set = CharSet.getInstance("----");
        array = set.getCharRanges();
        assertEquals(1, array.size());
        assertTrue(array.contains(CharRange.is('-')));

        set = CharSet.getInstance("-a");
        array = set.getCharRanges();
        assertEquals(2, array.size());
        assertTrue(array.contains(CharRange.is('-')));
        assertTrue(array.contains(CharRange.is('a')));

        set = CharSet.getInstance("a-");
        array = set.getCharRanges();
        assertEquals(2, array.size());
        assertTrue(array.contains(CharRange.is('a')));
        assertTrue(array.contains(CharRange.is('-')));

        set = CharSet.getInstance("a--");
        array = set.getCharRanges();
        assertEquals(1, array.size());
        assertTrue(array.contains(CharRange.isIn('a', '-')));

        set = CharSet.getInstance("--a");
        array = set.getCharRanges();
        assertEquals(1, array.size());
        assertTrue(array.contains(CharRange.isIn('-', 'a')));
    }

    @Test
    void testConstructor_String_oddNegate() {
        CharSet set;
        Set<CharRange> array;
        set = CharSet.getInstance("^");
        array = set.getCharRanges();
        assertEquals(1, array.size());
        assertTrue(array.contains(CharRange.is('^'))); // "^"

        set = CharSet.getInstance("^^");
        array = set.getCharRanges();
        assertEquals(1, array.size());
        assertTrue(array.contains(CharRange.isNot('^'))); // "^^"

        set = CharSet.getInstance("^^^");
        array = set.getCharRanges();
        assertEquals(2, array.size());
        assertTrue(array.contains(CharRange.isNot('^'))); // "^^"
        assertTrue(array.contains(CharRange.is('^'))); // "^"

        set = CharSet.getInstance("^^^^");
        array = set.getCharRanges();
        assertEquals(1, array.size());
        assertTrue(array.contains(CharRange.isNot('^'))); // "^^" x2

        set = CharSet.getInstance("a^");
        array = set.getCharRanges();
        assertEquals(2, array.size());
        assertTrue(array.contains(CharRange.is('a'))); // "a"
        assertTrue(array.contains(CharRange.is('^'))); // "^"

        set = CharSet.getInstance("^a-");
        array = set.getCharRanges();
        assertEquals(2, array.size());
        assertTrue(array.contains(CharRange.isNot('a'))); // "^a"
        assertTrue(array.contains(CharRange.is('-'))); // "-"

        set = CharSet.getInstance("^^-c");
        array = set.getCharRanges();
        assertEquals(1, array.size());
        assertTrue(array.contains(CharRange.isNotIn('^', 'c'))); // "^^-c"

        set = CharSet.getInstance("^c-^");
        array = set.getCharRanges();
        assertEquals(1, array.size());
        assertTrue(array.contains(CharRange.isNotIn('c', '^'))); // "^c-^"

        set = CharSet.getInstance("^c-^d");
        array = set.getCharRanges();
        assertEquals(2, array.size());
        assertTrue(array.contains(CharRange.isNotIn('c', '^'))); // "^c-^"
        assertTrue(array.contains(CharRange.is('d'))); // "d"

        set = CharSet.getInstance("^^-");
        array = set.getCharRanges();
        assertEquals(2, array.size());
        assertTrue(array.contains(CharRange.isNot('^'))); // "^^"
        assertTrue(array.contains(CharRange.is('-'))); // "-"
    }

    @Test
    void testConstructor_String_simple() {
        CharSet set;
        Set<CharRange> array;

        set = CharSet.getInstance((String) null);
        array = set.getCharRanges();
        assertEquals("[]", set.toString());
        assertEquals(0, array.size());

        set = CharSet.getInstance("");
        array = set.getCharRanges();
        assertEquals("[]", set.toString());
        assertEquals(0, array.size());

        set = CharSet.getInstance("a");
        array = set.getCharRanges();
        assertEquals("[a]", set.toString());
        assertEquals(1, array.size());
        assertEquals("a", array.iterator().next().toString());

        set = CharSet.getInstance("^a");
        array = set.getCharRanges();
        assertEquals("[^a]", set.toString());
        assertEquals(1, array.size());
        assertEquals("^a", array.iterator().next().toString());

        set = CharSet.getInstance("a-e");
        array = set.getCharRanges();
        assertEquals("[a-e]", set.toString());
        assertEquals(1, array.size());
        assertEquals("a-e", array.iterator().next().toString());

        set = CharSet.getInstance("^a-e");
        array = set.getCharRanges();
        assertEquals("[^a-e]", set.toString());
        assertEquals(1, array.size());
        assertEquals("^a-e", array.iterator().next().toString());
    }

    @Test
    void testContains_Char() {
        final CharSet btod = CharSet.getInstance("b-d");
        final CharSet dtob = CharSet.getInstance("d-b");
        final CharSet bcd = CharSet.getInstance("bcd");
        final CharSet bd = CharSet.getInstance("bd");
        final CharSet notbtod = CharSet.getInstance("^b-d");

        assertFalse(btod.contains('a'));
        assertTrue(btod.contains('b'));
        assertTrue(btod.contains('c'));
        assertTrue(btod.contains('d'));
        assertFalse(btod.contains('e'));

        assertFalse(bcd.contains('a'));
        assertTrue(bcd.contains('b'));
        assertTrue(bcd.contains('c'));
        assertTrue(bcd.contains('d'));
        assertFalse(bcd.contains('e'));

        assertFalse(bd.contains('a'));
        assertTrue(bd.contains('b'));
        assertFalse(bd.contains('c'));
        assertTrue(bd.contains('d'));
        assertFalse(bd.contains('e'));

        assertTrue(notbtod.contains('a'));
        assertFalse(notbtod.contains('b'));
        assertFalse(notbtod.contains('c'));
        assertFalse(notbtod.contains('d'));
        assertTrue(notbtod.contains('e'));

        assertFalse(dtob.contains('a'));
        assertTrue(dtob.contains('b'));
        assertTrue(dtob.contains('c'));
        assertTrue(dtob.contains('d'));
        assertFalse(dtob.contains('e'));

        final Set<CharRange> array = dtob.getCharRanges();
        assertEquals("[b-d]", dtob.toString());
        assertEquals(1, array.size());
    }

    @Test
    void testEquals_Object() {
        final CharSet abc = CharSet.getInstance("abc");
        final CharSet abc2 = CharSet.getInstance("abc");
        final CharSet atoc = CharSet.getInstance("a-c");
        final CharSet atoc2 = CharSet.getInstance("a-c");
        final CharSet notatoc = CharSet.getInstance("^a-c");
        final CharSet notatoc2 = CharSet.getInstance("^a-c");

        assertNotEquals(null, abc);

        assertEquals(abc, abc);
        assertEquals(abc, abc2);
        assertNotEquals(abc, atoc);
        assertNotEquals(abc, notatoc);

        assertNotEquals(atoc, abc);
        assertEquals(atoc, atoc);
        assertEquals(atoc, atoc2);
        assertNotEquals(atoc, notatoc);

        assertNotEquals(notatoc, abc);
        assertNotEquals(notatoc, atoc);
        assertEquals(notatoc, notatoc);
        assertEquals(notatoc, notatoc2);
    }

    @Test
    void testGetInstance() {
        assertSame(CharSet.EMPTY, CharSet.getInstance((String) null));
        assertSame(CharSet.EMPTY, CharSet.getInstance((String[]) null));
        assertSame(CharSet.EMPTY, CharSet.getInstance(null));
        assertSame(CharSet.EMPTY, CharSet.getInstance(""));
        assertSame(CharSet.ASCII_ALPHA, CharSet.getInstance("a-zA-Z"));
        assertSame(CharSet.ASCII_ALPHA, CharSet.getInstance("A-Za-z"));
        assertSame(CharSet.ASCII_ALPHA_LOWER, CharSet.getInstance("a-z"));
        assertSame(CharSet.ASCII_ALPHA_UPPER, CharSet.getInstance("A-Z"));
        assertSame(CharSet.ASCII_NUMERIC, CharSet.getInstance("0-9"));
    }

    @Test
    void testGetInstance_Stringarray() {
        assertEquals("[]", CharSet.getInstance((String[]) null).toString());
        assertEquals("[]", CharSet.getInstance().toString());
        assertEquals("[]", CharSet.getInstance(new String[] {null}).toString());
        assertEquals("[a-e]", CharSet.getInstance("a-e").toString());
    }

    @Test
    void testHashCode() {
        final CharSet abc = CharSet.getInstance("abc");
        final CharSet abc2 = CharSet.getInstance("abc");
        final CharSet atoc = CharSet.getInstance("a-c");
        final CharSet atoc2 = CharSet.getInstance("a-c");
        final CharSet notatoc = CharSet.getInstance("^a-c");
        final CharSet notatoc2 = CharSet.getInstance("^a-c");

        assertEquals(abc.hashCode(), abc.hashCode());
        assertEquals(abc.hashCode(), abc2.hashCode());
        assertEquals(atoc.hashCode(), atoc.hashCode());
        assertEquals(atoc.hashCode(), atoc2.hashCode());
        assertEquals(notatoc.hashCode(), notatoc.hashCode());
        assertEquals(notatoc.hashCode(), notatoc2.hashCode());
    }

    @Test
    void testJavadocExamples() {
        assertFalse(CharSet.getInstance("^a-c").contains('a'));
        assertTrue(CharSet.getInstance("^a-c").contains('d'));
        assertTrue(CharSet.getInstance("^^a-c").contains('a'));
        assertFalse(CharSet.getInstance("^^a-c").contains('^'));
        assertTrue(CharSet.getInstance("^a-cd-f").contains('d'));
        assertTrue(CharSet.getInstance("a-c^").contains('^'));
        assertTrue(CharSet.getInstance("^", "a-c").contains('^'));
    }

    @Test
    void testSerialization() {
        CharSet set = CharSet.getInstance("a");
        assertEquals(set, SerializationUtils.clone(set));
        set = CharSet.getInstance("a-e");
        assertEquals(set, SerializationUtils.clone(set));
        set = CharSet.getInstance("be-f^a-z");
        assertEquals(set, SerializationUtils.clone(set));
    }

    @Test
    void testStatics() {
        Set<CharRange> array;

        array = CharSet.EMPTY.getCharRanges();
        assertEquals(0, array.size());

        array = CharSet.ASCII_ALPHA.getCharRanges();
        assertEquals(2, array.size());
        assertTrue(array.contains(CharRange.isIn('a', 'z')));
        assertTrue(array.contains(CharRange.isIn('A', 'Z')));

        array = CharSet.ASCII_ALPHA_LOWER.getCharRanges();
        assertEquals(1, array.size());
        assertTrue(array.contains(CharRange.isIn('a', 'z')));

        array = CharSet.ASCII_ALPHA_UPPER.getCharRanges();
        assertEquals(1, array.size());
        assertTrue(array.contains(CharRange.isIn('A', 'Z')));

        array = CharSet.ASCII_NUMERIC.getCharRanges();
        assertEquals(1, array.size());
        assertTrue(array.contains(CharRange.isIn('0', '9')));
    }
}
